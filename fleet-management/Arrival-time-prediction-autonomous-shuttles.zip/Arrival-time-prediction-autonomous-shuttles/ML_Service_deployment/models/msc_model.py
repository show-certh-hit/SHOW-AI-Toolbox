import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GCNConv
import random
from typing import Callable, Tuple, Union, Optional, List
from constants import *
from torch import nn
from omegaconf import OmegaConf
import logging

log = logging.getLogger(__name__)


# assuming than no 0 vales in y_true
def mape(y_true, y_pred):
    """
    Computes MAPE error between the true values and the prediction of the model
    """
    return torch.mean(torch.abs(y_true - y_pred) / y_true) * 100


# used for SEGMENTS BETWEEN STOPS
class GCN_segments(torch.nn.Module):
    def __init__(
        self, input_size: int, hidden_layers: List[int], drop_p: float = 0.5
    ) -> None:
        """Builds a graph convolutional neural network network.

        Arguments
        ---------
        input_size: integer, size of the input layer
        output_size: integer, size of the output layer
        hidden_layers: list of integers, the sizes of the conv layers

        """

        super().__init__()
        self.conv1 = GCNConv(input_size, hidden_layers[0])
        self.conv2 = GCNConv(hidden_layers[0], hidden_layers[1])
        self.conv3 = GCNConv(hidden_layers[1], hidden_layers[2])
        self.linear = torch.nn.Linear(hidden_layers[2], 1)
        self.dropout1 = nn.Dropout(p=drop_p)
        self.dropout2 = nn.Dropout(p=drop_p)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index

        x = F.relu(self.conv1(x, edge_index))
        x = self.dropout(x)
        x = F.relu(self.conv2(x, edge_index))
        x = self.dropout(x)
        x = F.relu(self.conv3(x, edge_index))
        x = self.linear(x)

        return x


def validation(
    model: nn.Module,
    testloader: torch.utils.data.DataLoader,
    criterion: Union[Callable, nn.Module],
) -> Tuple[float, float]:
    mmapese = 0
    test_loss = 0
    for data in testloader:
        images = images.resize_(images.size()[0], 784)

        output = model.forward(data)
        test_loss += criterion(output, data.y).item()
        # mape +=
    return test_loss, mape


def train(
    model: nn.Module,
    train_loader: torch.utils.data.DataLoader,
    val_loader: torch.utils.data.DataLoader,
    criterion: Union[Callable, nn.Module],
    optimizer: Optional[torch.optim.Optimizer] = None,
    epochs: int = 5,
    print_every: int = 10,
):
    losses_train = []
    mapes_train = []

    log.info("Training started...")
    best_loss = np.inf
    for epoch in range(epochs):
        model.train()
        losses_epoch_train = []
        mapes_epoch_train = []

        for data in train_loader:
            data_cuda = data.to(device)
            optimizer.zero_grad()

            out = model(data_cuda)
            y_true = data_cuda.y.type(torch.float)
            y_true = torch.reshape(y_true, (-1, 1))

            true_samples_mask = (
                data_cuda.x[:, -1] != 0
            )  # checks if last element in each tensor is different than 0
            true_samples_mask = true_samples_mask.reshape(([-1, 1]))

            loss = criterion(y_true[true_samples_mask], out[true_samples_mask])
            mape_error = mape(y_true[true_samples_mask], out[true_samples_mask])

            loss.backward()
            optimizer.step()

            losses_epoch_train.append(loss.cpu().detach().numpy())
            mapes_epoch_train.append(mape_error.cpu().detach().numpy())

        loss_epoch_train = np.mean(losses_epoch_train)
        mape_epoch_train = np.mean(mapes_epoch_train)

        losses_train.append(loss_epoch_train)
        mapes_train.append(mape_epoch_train)

        if epoch % print_every == 0:
            # Model in inference mode, dropout is off
            model.eval()

            # Turn off gradients for validation, will speed up inference
            with torch.no_grad():
                val_loss, mape_val = validation(model, val_loader, criterion)
                if best_loss <= val_loss:
                    model.save_checkpoint("./models")

            log.info(
                f"Epoch {epoch+1} complete! Average Training Loss: {loss_epoch_train,mape_epoch_train }"
            )
            log.info(f"Average Validation Loss: {val_loss, mape_val }")
            # Make sure dropout and grads are on for training
            model.train()


if __name__ == "__main__":
    cfg = OmegaConf.load("/conf/config.yaml")

    random.seed(cfg.seed)
    np.random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)

    device = torch.device(
        "cuda" if (torch.cuda.is_available() and cfg.use_cuda) else "cpu"
    )

    model = GCN_segments().to(device)

    criterion = torch.nn.MSELoss()

    optimizer = torch.optim.Adam(
        model.parameters(), cfg.lerning_rate, weight_decay=5e-4
    )

    epochs = cfg.n_epochs

    data_train = pd.read_csv("./data/processed/data_train.csv", delimiter=",", header=0)
    print(len(data_train))
    data_train = data_train[:-1]
    data_train = data_train[
        data_train.columns[
            ~data_train.columns.isin(
                [
                    "segment_id",
                    "coco",
                    "date",
                    "dow",
                    "dow_day",
                    "tod",
                    "condition",
                    "tod_encoded",
                ]
            )
        ]
    ]
    X_train = data_train.loc[:, ~data_train.columns.isin(["travel_time"])].values
    data_val = pd.read_csv("./data/processed/data_val.csv", delimiter=",", header=0)

    train_loader = DataLoader(data_train, batch_size=cfg.batch_size, shuffle=False)
    val_loader = DataLoader(data_val, batch_size=cfg.batch_size, shuffle=False)

    train(
        model, train_loader, val_loader, criterion, optimizer, epochs, cfg.print_every
    )

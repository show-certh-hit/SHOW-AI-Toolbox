from omegaconf import DictConfig, OmegaConf
import hydra


@hydra.main(version_base="1.3", config_path="../conf", config_name="config")
def my_app(cfg: DictConfig) -> None:
    print(OmegaConf.to_yaml(cfg))

    print(cfg.model.model_parameters.hidden_dims)


if __name__ == "__main__":
    my_app()

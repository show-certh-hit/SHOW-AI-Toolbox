import pytorch_lightning as pl
import torch
from torch import nn
import torch.nn.functional as F
from torch import Tensor
from torchmetrics import MeanAbsolutePercentageError
from typing import Any
from data.datamodule import Standardize


class BaseModelClass(pl.LightningModule):
    def __init__(self, lr: float, weight_decay: float, batch_size: int, transform: Standardize) -> None:
        super().__init__()

        self.loss = nn.MSELoss()
        self.mape = MeanAbsolutePercentageError()

        self.lr = lr
        self.weight_decay = weight_decay
        self.transform = transform

    def training_step(self, batch: Any, batch_idx: int) -> Tensor:
        loss, _, _ = self.standard_step(batch=batch, step_type="train")
        return loss

    def validation_step(self, batch: Any, batch_idx: int) -> Tensor:
        self.standard_step(batch=batch, step_type="val")

    def test_step(self, batch: Any, batch_idx: int) -> Tensor:
        _, y_hat_batch, y_true_batch = self.standard_step(batch=batch, step_type="test")
        return {"y_hat": y_hat_batch, "y_true": y_true_batch}

    def predict_step(self, batch: Any, batch_idx: int, dataloader_idx: int = 0) -> Any:
        self.eval()
        with torch.no_grad():
            batch_size = 1
            x = batch.x
            edge_index = batch.edge_index
            u = batch.global_feat.reshape(batch_size, -1)
            node_encoding = batch.node_encoding
            num_nodes = node_encoding.shape[-1]

            y_hat = self.forward(
                x=x, u=u, node_encoding=node_encoding, edge_index=edge_index, batch_size=batch_size
            ).squeeze()

        rt_y_hat = self.transform.retransform_target_vals(y_hat)

        return rt_y_hat

    def test_epoch_end(self, output_results: Tensor):
        # TODO
        return None

    # TODO match this with however we put x and y into the batch
    def standard_step(self, batch: Tensor, step_type: int) -> Tensor:
        batch_size = len(batch.batch.unique())
        x = batch.x
        edge_index = batch.edge_index
        u = batch.global_feat.reshape(batch_size, -1)
        node_encoding = batch.node_encoding
        num_nodes = node_encoding.shape[-1]

        y_true = batch.y.reshape(batch_size, -1)
        true_obs_idxs = y_true[:, 0].long()
        true_obs_mask = F.one_hot(true_obs_idxs, num_nodes).reshape(-1).bool()

        true_obs_tt = y_true[:, 1]

        y_hat = self.forward(
            x=x, u=u, node_encoding=node_encoding, edge_index=edge_index, batch_size=batch_size
        ).squeeze()
        y_hat = y_hat[true_obs_mask]

        loss = self.loss(y_hat, true_obs_tt)
        mape = self.mape(y_hat, true_obs_tt)

        rtfed_y_hat = self.transform.retransform_target_vals(y_hat)
        rtfed_true_obs_tt = self.transform.retransform_target_vals(true_obs_tt)
        real_scale_loss = self.loss(rtfed_y_hat, rtfed_true_obs_tt)

        if step_type == "train":
            self.log(f"{step_type}/loss", loss, batch_size=64, on_step=True, on_epoch=False)
            self.log(
                f"{step_type}/real_scale_loss",
                real_scale_loss,
                batch_size=64,
                on_step=True,
                on_epoch=False,
            )
            self.log(f"{step_type}/mape", mape, batch_size=64, on_step=True, on_epoch=False)
        else:
            self.log(f"{step_type}/loss", loss, batch_size=64, on_step=False, on_epoch=True)
            self.log(
                f"{step_type}/real_scale_loss",
                real_scale_loss,
                batch_size=64,
                on_step=False,
                on_epoch=True,
            )
            self.log(f"{step_type}/mape", mape, batch_size=64, on_step=False, on_epoch=True)
        return loss, y_hat.detach(), y_true.detach()

    def configure_optimizers(self) -> Any:
        optimizer = torch.optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        return optimizer

from sklearn.base import BaseEstimator, RegressorMixin

import pandas as pd
import numpy as np

from generate_segments_functions import encode_tod, datetime_range
from constants import (
    SEGMENTS_OH,
    WEATHER_CONDITIONS,
    DICT_TIME_ENCODING,
    STOPS_OH,
    SEGMENTS_BETWEEN_STOPS_OH,
)

import datetime
from datetime import timedelta


class MeanRegressor(BaseEstimator, RegressorMixin):
    """Model that predicts always the mean value of travel_time of all the segments.
    Args:
        BaseEstimator (_type_): _description_
        RegressorMixin (_type_): _description_
    """

    def __init__(self, constant=None):
        self.constant = constant

    def fit(self, X, y=None):
        self.constant = np.average(y, axis=0)
        self.constant = np.reshape(self.constant, 1)
        return self

    def predict(self, X, y=None):
        n_samples = X.shape[0]
        y = np.full((1, n_samples), self.constant)
        return y[0]


class MeanRegressorSegments(BaseEstimator, RegressorMixin):
    """Model that predicts the mean value of travel_time in the specific segment computed from the training data
    Args:
        BaseEstimator (_type_): _description_
        RegressorMixin (_type_): _description_
    """

    def __init__(self):
        self.constants = (
            {}
        )  # contains all the values of the predictions (key:segment and value:prediction)

    def fit(self, X, y, weather=True):
        if weather:
            columns = (
                [
                    "temp",
                    "prcp",
                    "snow",
                    "wspd",
                    "dow_sin",
                    "dow_cos",
                    "tod_sin",
                    "tod_cos",
                ]
                + SEGMENTS_OH
                + WEATHER_CONDITIONS
            )
        else:
            columns = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

        df = pd.DataFrame(data=X, columns=columns)
        df["y_train"] = y

        # creates a dictionary which contains the average travel_time for each segment computed from the training data
        dict_pred = {}

        # computes the mean for each segment and saves it in the dictionary
        for col in SEGMENTS_OH:
            dict_pred[col] = df[df[col] == 1]["y_train"].mean()

        self.constants = dict_pred

    def predict(self, X, y=None, weather=True):
        # predicts the mean value of travel_time for each of the segments
        y_predi = np.empty(
            X.shape[0],
        )
        oh_segments = np.array(SEGMENTS_OH)  # all possible segments
        if weather:
            oh_data = X[:, 8:35]
        else:
            oh_data = X[
                :, 4:
            ]  # keeping columns corresponding to one hot encoding of segments
        indexes = np.where(oh_data == 1)[1]  # positions of the ones in each row
        segments = oh_segments[indexes]  # segment to which corresponds each sample
        y_predi = np.array(
            [self.constants[segment] for segment in segments]
        )  # prediction for each segment: average of that segment
        return y_predi


class LastOcurrenceSegmentPredictor(BaseEstimator, RegressorMixin):
    """Model that predicts the travel time as the most recent occurrence of travel time in the specific segment seen in the training data
        Returns the previous time of the day, already encoded: (tod_sin, tod_cos)
    Args:
        BaseEstimator (_type_): _description_
        RegressorMixin (_type_): _description_
    """

    def previous_tod(self, tod_sin, tod_cos):
        try:
            actual_tod = self.time_mapping.loc[
                (self.time_mapping["tod_sin"] == np.round(tod_sin, decimals=6))
                & (self.time_mapping["tod_cos"] == np.round(tod_cos, decimals=6))
            ]["tod"].values[
                0
            ]  # actual tod
        except:
            print(
                "Hour corresponding to tod_sin: {} and tod_cos: {} not found".format(
                    tod_sin, tod_cos
                )
            )
        actual_tod_index = DICT_TIME_ENCODING[actual_tod]  # index of actual tod
        prev_tod_index = actual_tod_index - 1  # index of previous tod
        if prev_tod_index == -1:
            prev_tod_index = 95
        prev_tod = self.time_list[prev_tod_index]
        return prev_tod[2], prev_tod[3]

    """
    Searches the value that will be used as prediction for the specific segment and time of day in the training data.
    Returns the value of 'travel_time' in the same segment in the closest previous time of the day.
    """

    def prediction(self, values, tod_sin, tod_cos, weather):
        # print('Looking for previous at {} and {}'.format(tod_sin, tod_cos))
        if weather:
            segment = SEGMENTS_OH[values[8:35].tolist().index(1)]
        else:
            segment = SEGMENTS_OH[
                values[4:].tolist().index(1)
            ]  # gets the segment for which we want to predict the travel time

        prediction = -1
        prev_tod_sin, prev_tod_cos = self.previous_tod(tod_sin, tod_cos)

        safety_counter = 0
        while (prediction == -1) and (safety_counter < 30):
            # print('While executed {}'.format(safety_counter))
            prev_ocurrences = self.data[
                (self.data["segment_oh"] == segment)
                & (self.data["tod_sin"] == prev_tod_sin)
                & (self.data["tod_cos"] == prev_tod_cos)
            ]["y_train"].values
            if prev_ocurrences.size > 0:
                prediction = prev_ocurrences[
                    -1
                ]  # taking the last element = most recent sample
            else:
                prev_tod_sin, prev_tod_cos = self.previous_tod(
                    prev_tod_sin, prev_tod_cos
                )
                safety_counter += 1

            if safety_counter == 30:
                prediction = self.data[(self.data["segment_oh"] == segment)][
                    "y_train"
                ].mean()
                print(
                    "Previous sample to {} and {} not found. Predicting mean for {}".format(
                        tod_sin, tod_cos, segment
                    )
                )

        return prediction

    def __init__(self, data=None):
        # preparing necessary elements
        tod_intervals = []
        for key, value in DICT_TIME_ENCODING.items():
            tod_intervals.append(key)

        time = pd.DataFrame(data=tod_intervals, columns=["tod"])
        time = encode_tod(time)  # import function from processing data for ML
        time_list = time.values.tolist()

        self.time_mapping = time  # mapping: tod, tod_encoded, tod_sin, tod_cos
        self.time_list = time_list
        self.tod_intervals = tod_intervals  # list with tod intervals
        self.data = data  # training data from which predictions will be extracted

    def fit(self, X, y, weather=True):
        if weather:
            columns = (
                [
                    "temp",
                    "prcp",
                    "snow",
                    "wspd",
                    "dow_sin",
                    "dow_cos",
                    "tod_sin",
                    "tod_cos",
                ]
                + SEGMENTS_OH
                + WEATHER_CONDITIONS
            )
        else:
            columns = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

        df = pd.DataFrame(data=X, columns=columns)
        df["y_train"] = y
        if weather:
            df["segment_oh"] = df.apply(
                lambda row: SEGMENTS_OH[row.values[8:35].tolist().index(1)], axis=1
            )  # adds column with the segment to which the sample corresponds
        else:
            df["segment_oh"] = df.apply(
                lambda row: SEGMENTS_OH[row.values[4:].tolist().index(1)], axis=1
            )  # adds column with the segment to which the sample corresponds
        self.data = df

    def predict(self, X, y=None, weather=True):
        if weather:
            columns = (
                [
                    "temp",
                    "prcp",
                    "snow",
                    "wspd",
                    "dow_sin",
                    "dow_cos",
                    "tod_sin",
                    "tod_cos",
                ]
                + SEGMENTS_OH
                + WEATHER_CONDITIONS
            )
        else:
            columns = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

        data_test = pd.DataFrame(data=X, columns=columns)

        if weather:
            data_test["segment_oh"] = data_test.apply(
                lambda row: SEGMENTS_OH[row.values[8:35].tolist().index(1)], axis=1
            )
        else:
            # get the values [4:] from the row and find the index of the one that is 1. Use that index to get the element from cols_oh => segment name
            data_test["segment_oh"] = data_test.apply(
                lambda row: SEGMENTS_OH[row.values[4:].tolist().index(1)], axis=1
            )

        data_test["y_pred"] = data_test.apply(
            lambda row: self.prediction(
                row.values, row["tod_sin"], row["tod_cos"], weather
            ),
            axis=1,
        )

        return data_test["y_pred"].to_numpy()


class MeanRegressorToD(BaseEstimator, RegressorMixin):
    """Model that predicts the mean value of 'travel_time' for a specific time of the day
    Args:
        BaseEstimator (_type_): _description_
        RegressorMixin (_type_): _description_
    """

    def __init__(self):
        # preparing necessary elements
        tod_intervals = []
        for key, value in DICT_TIME_ENCODING.items():
            tod_intervals.append(key)
        time_mapping = pd.DataFrame(data=tod_intervals, columns=["tod"])
        time_mapping = encode_tod(time_mapping)[["tod_sin", "tod_cos", "tod"]]
        # time['y_train'] = None

        self.time = time_mapping

        # contains all the values of the predictions - dictionary with dictionaries
        # (key:segment and values (2nd level keys): tod -> values: )
        self.constants = {}

    def fit(self, X, y, weather=True):
        if weather:
            columns = (
                [
                    "temp",
                    "prcp",
                    "snow",
                    "wspd",
                    "dow_sin",
                    "dow_cos",
                    "tod_sin",
                    "tod_cos",
                ]
                + SEGMENTS_OH
                + WEATHER_CONDITIONS
            )
        else:
            columns = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

        df = pd.DataFrame(data=X, columns=columns)
        df["y_train"] = y

        if weather:
            df["segment_oh"] = df.apply(
                lambda row: SEGMENTS_OH[row.values[8:35].tolist().index(1)], axis=1
            )
        else:
            # get the values [4:] from the row and find the index of the one that is 1. Use that index to get the element from cols_oh => segment name
            df["segment_oh"] = df.apply(
                lambda row: SEGMENTS_OH[row.values[4:].tolist().index(1)], axis=1
            )

        dict_tod = (
            {}
        )  # contains all the values of the predictions - dictionary with dictionaries
        # (key:segment and values (2nd level keys): tod -> values: )

        for segment in SEGMENTS_OH:
            ds = df[
                df["segment_oh"] == segment
            ]  # samples corresponding to the specific segment
            ds = ds.groupby(["tod_sin", "tod_cos"])["y_train"].mean()

            columns = ["tod_sin", "tod_cos", "y_train"]
            time_intervals = []

            for tod, travel_time in zip(ds.index.tolist(), ds.values.tolist()):
                time_intervals.append([tod[0], tod[1], travel_time])

                #'time_intervals_data' contains the intervals present in the training data
                time_intervals_data = pd.DataFrame(data=time_intervals, columns=columns)

                # merging 'time' and 'time_intervals_data' to add possible values that dont appear in the training data
                all_times = pd.merge(
                    time_intervals_data,
                    self.time,
                    on=["tod_sin", "tod_cos"],
                    how="right",
                )
                all_times = all_times.rename(columns={"y_train_x": "y_train"})[
                    ["tod", "tod_sin", "tod_cos", "y_train"]
                ]
                all_times = all_times.fillna(
                    all_times["y_train"].mean()
                )  # filling null values with the mean of the column
                dict_time_intervals = (
                    all_times[["tod", "y_train"]].set_index("tod").T.to_dict("dict")
                )

            dict_tod[segment] = dict_time_intervals

        self.constants = dict_tod

    def predict(self, X, y=None, weather=True):
        if weather:
            columns = (
                [
                    "temp",
                    "prcp",
                    "snow",
                    "wspd",
                    "dow_sin",
                    "dow_cos",
                    "tod_sin",
                    "tod_cos",
                ]
                + SEGMENTS_OH
                + WEATHER_CONDITIONS
            )
        else:
            columns = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

        data_test = pd.DataFrame(data=X, columns=columns)

        if weather:
            data_test["segment_oh"] = data_test.apply(
                lambda row: SEGMENTS_OH[row.values[8:35].tolist().index(1)], axis=1
            )
        else:
            # get the values [4:] from the row and find the index of the one that is 1. Use that index to get the element from cols_oh => segment name
            data_test["segment_oh"] = data_test.apply(
                lambda row: SEGMENTS_OH[row.values[4:].tolist().index(1)], axis=1
            )

        # sometimes these values are not rounded properly yet
        data_test["tod_sin"] = np.round(data_test["tod_sin"], decimals=6)
        data_test["tod_cos"] = np.round(data_test["tod_cos"], decimals=6)

        data_test = pd.merge(
            data_test,
            self.time[["tod", "tod_sin", "tod_cos"]],
            on=["tod_sin", "tod_cos"],
            how="left",
        )  # adds column tod to be able to search in the dictionary
        data_test["y_pred"] = data_test.apply(
            lambda row: self.constants[row["segment_oh"]][row["tod"]]["y_train"], axis=1
        )
        return data_test["y_pred"].to_numpy()


def simple_model_evaluation(y_train, y_test, y_pred_train, y_pred_test):
    # Simple model evaluation that computes and prints MSE, RMSE and MAPE for the training and testing set

    train_error_mse = np.square(y_train - y_pred_train).sum() / y_train.shape[0]
    test_error_mse = np.square(y_test - y_pred_test).sum() / y_test.shape[0]

    train_error_mape = (100 / y_train.shape[0]) * (
        np.absolute(y_train - y_pred_train) / y_train
    ).sum()  # y_train should never be 0 since the travel time in a segment cannot be 0
    test_error_mape = (100 / y_test.shape[0]) * (
        np.absolute(y_test - y_pred_test) / y_test
    ).sum()

    print("-----------MSE----------")
    print("Training error: {}".format(train_error_mse))
    print("Testing error: {}".format(test_error_mse))
    print("-----------RMSE----------")
    print("Training error: {}".format(np.sqrt(train_error_mse)))
    print("Testing error: {}".format(np.sqrt(test_error_mse)))
    print("-----------MAPE----------")
    print("Training error: {:.2f} %".format(train_error_mape))
    print("Testing error: {:.2f} %".format(test_error_mape))


def advanced_model_evaluation(X_test, y_test, y_pred_test, weather=True):
    # Model evaluation of the testing part. Returns a dataset in which it is possible to visualize the errors
    # (MAE, MSE, RMSE and MAPE) in every segment and all the dataset
    if weather:
        cols = (
            ["temp", "prcp", "snow", "wspd", "dow_sin", "dow_cos", "tod_sin", "tod_cos"]
            + SEGMENTS_OH
            + WEATHER_CONDITIONS
        )
    else:
        cols = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + SEGMENTS_OH

    data_err = pd.DataFrame(data=X_test, columns=cols)
    data_err["y_test"] = y_test  # ground truth
    data_err["y_pred"] = y_pred_test  # predictions
    data_err["error"] = data_err["y_test"] - data_err["y_pred"]

    # creating dataset with errors for each segment, and type of segments
    data_columns = ["segment", "mean error", "MAE", "MSE", "RSME", "MAPE"]
    data_error = []
    stops_errors = []
    segments_errors = []

    # computing errors for the data of each segment
    for segment in SEGMENTS_OH:
        n_elements = len(data_err[data_err[segment] == 1])
        errors = data_err[data_err[segment] == 1][
            "error"
        ].values  # list with the column errors for each segment

        mean_error = errors.mean()
        mae = np.sum(np.absolute(errors)) / n_elements
        mse = np.sum(errors ** 2) / n_elements
        rmse = np.sqrt(mse)
        mape = (100 / n_elements) * np.sum(
            np.absolute(errors) / data_err[data_err[segment] == 1]["y_test"]
        )
        data_error.append([segment, mean_error, mae, mse, rmse, mape])

    # adding error values for the whole dataset
    n_elements = len(data_err)
    mean_error = (data_err["error"].values).mean()
    mae = np.sum(np.absolute((data_err["error"].values))) / n_elements
    mse = np.sum((data_err["error"].values) ** 2) / n_elements
    rmse = np.sqrt(mse)
    mape = (100 / n_elements) * np.sum(np.absolute(y_test - y_pred_test) / y_test)
    data_error.append(["all segments", mean_error, mae, mse, rmse, mape])

    # adding error values for segments corresponding to stops
    data_err["segment_oh"] = data_err.apply(
        lambda row: SEGMENTS_OH[row.values[8:35].tolist().index(1)], axis=1
    )
    stops = data_err[data_err["segment_oh"].isin(STOPS_OH)]
    n_elements = len(stops)
    stops_errors = stops["error"].values

    mean_error = stops_errors.mean()
    mae = np.sum(np.absolute(stops_errors)) / n_elements
    mse = np.sum(stops_errors ** 2) / n_elements
    rmse = np.sqrt(mse)
    mape = (100 / n_elements) * np.sum(np.absolute(stops_errors) / stops["y_test"])
    data_error.append(["stops", mean_error, mae, mse, rmse, mape])

    # adding error values for segments corresponding to segments between stops
    segments = data_err[data_err["segment_oh"].isin(SEGMENTS_BETWEEN_STOPS_OH)]
    n_elements = len(segments)
    segments_errors = segments["error"].values

    mean_error = segments_errors.mean()
    mae = np.sum(np.absolute(segments_errors)) / n_elements
    mse = np.sum(segments_errors ** 2) / n_elements
    rmse = np.sqrt(mse)
    mape = (100 / n_elements) * np.sum(
        np.absolute(segments_errors) / segments["y_test"]
    )
    data_error.append(["segments between stops", mean_error, mae, mse, rmse, mape])

    errors_df = pd.DataFrame(data=data_error, columns=data_columns)
    return errors_df, data_err

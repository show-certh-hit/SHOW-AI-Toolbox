from stops import STOPS_LONG
from stops_info_functions import generate_stops_order, next_stop, day_of_week
from generate_segments_functions import encode_dow, encode_tod, one_hot_encode

import pandas as pd
import numpy as np

import datetime
from datetime import timedelta
import dateutil.parser

"""
Computes the route between two stops, returning a list with all the segments (including segments between stops and stops)
that the bus must visit to arrive to the destination stop.
"""


def compute_route(origin_stop, destination_stop):
    # Initialization of the dictionaries
    # If they are not initializaed, the functions from this file can only be used once add_stops_info(data) has been executed
    stops, ki, ik = generate_stops_order()

    # getting stops in the route
    route_stops = []
    s = origin_stop
    while s != destination_stop:
        route_stops.append(s)
        s = next_stop(s)
    route_stops.append(destination_stop)

    # getting segment in the route in the order that they will be visited
    route_segments = []
    route_segments.append(route_stops[0])
    for origin, destination in zip(route_stops, route_stops[1:]):
        route_segments.append(origin + "_" + destination)
        route_segments.append(destination)

    return route_segments


"""
Computes the difference between two datetimes (in seconds)
"""


def difference_two_datetimes(datetime1, datetime2):
    seconds_in_day = 24 * 60 * 60
    diff = datetime1 - datetime2
    return np.abs(diff.days * seconds_in_day + diff.seconds)


##############################################
# --------------MAIN FUNCTIONS----------------#
##############################################
"""
Predicts the estimated time of arrival to a stop ('destination_stop') from an actual stop ('origin_stop').
(From the perspective of the bus).Prediction is done segment by segment, updating the time with the predicted 
travel time for the segment.

+ model - ML mdel that will be used for making the predictions
+ encoder - encoder used for the one hot encoding of the segments
+ origin_stop - actual stop
+ destination_dtop - destination stop
+ date - date and hour (datetime object) for which the prediction must be performed

TO DO: to get the perspective of the user, it is also necessary to take into account the time that the bus 
will need to arrive to the stop in which the user is waiting.
"""


# CHANGE THIS ONE WITH THE ONE DEFINED IN NOTEBOOK ETA_FINAL_MODEL
def predict_ETA(
    model, encoder, origin_stop, destination_stop, date=datetime.datetime.now()
):
    # compute segments from origin to destination
    # get index of origin and destination stop -> better using function next_stop
    # create list with all the segments in the route from origin to destination
    # predict time for each segment in the specific date
    # create dataset with the segments from the route
    # encoding of the dataset with the corresponding encoders (especially important for the one hot encoding of segments)
    # TO DO:add weather to the dataset (weather in the future - forecasting - also possible to obtain from meteostat)
    # estimated time of arrival
    # not considering the time spent in the destination stop

    # compute segments from origin to destination
    segments_list = compute_route(
        origin_stop, destination_stop
    )  # TO DO: must be in order of visting them...
    # segments = [[segment] for segment in segments_list]

    total_travel_time = 0
    for segment in range(len(segments_list)):
        # creating necessary attributes for model
        segment_test = pd.DataFrame(
            data=[segments_list[segment]], columns=["segment_id"]
        )
        segment_test["date"] = (date + timedelta(seconds=total_travel_time)).replace(
            microsecond=0
        )  # taking into account already traveled time
        segment_test["dow"] = segment_test.apply(
            lambda row: day_of_week(row["date"]), axis=1
        )
        segment_test["tod"] = (
            (
                segment_test["date"]
                - pd.TimedeltaIndex(segment_test["date"].dt.minute % 15, "m")
            )
            - pd.TimedeltaIndex(segment_test["date"].dt.second, "s")
        ).dt.time
        segment_test["tod"] = segment_test.apply(lambda row: str(row["tod"]), axis=1)

        # encoding of the attributes
        segment_test = encode_dow(segment_test)
        segment_test = encode_tod(segment_test)
        segment_test, columns_oh = one_hot_encode(segment_test, encoder)

        # prepairing model input
        columns_reg = ["dow_sin", "dow_cos", "tod_sin", "tod_cos"] + columns_oh
        data_reg = segment_test[columns_reg]
        X_test = data_reg.values

        # predicting
        print(
            "- Segment {} at tod {}".format(
                segments_list[segment], segment_test.loc[0, "tod"]
            )
        )
        travel_time_pred_segment = model.predict(X_test)
        print("-- Predicted time: {:.2f} ".format(travel_time_pred_segment[0]))
        total_travel_time += travel_time_pred_segment[0]
        print("-- Total travel time: {:.2f}".format(total_travel_time))
        print("\n")

    total_travel_time -= travel_time_pred_segment[
        0
    ]  # last segment's time corresponds to time in stop
    eta = (date + timedelta(seconds=total_travel_time)).replace(microsecond=0)

    print(
        "{}->{} will take {:.2f} seconds. ETA: {}".format(
            origin_stop, destination_stop, total_travel_time, eta
        )
    )


"""
Computes the ground truth of the Time of Arrival from one stop to another one in a 
specific time. The result can be used to compare with the result of predict_ETA() in
order to get another metric about the performance of the model used for predictions.
"""


def ground_truth_ETA(
    origin_stop, destination_stop, date=datetime.datetime.now(), info=True
):
    # loads file data1year_notencoded
    path = "C:/Users/kubap/Desktop/DTU/Master_Thesis/Data/data1year_notencoded.csv"
    data = pd.read_csv(path, delimiter=",", header=0)
    data["date"] = data.apply(lambda row: dateutil.parser.parse(row["date"]), axis=1)
    # computes difference between all the times
    # data['diff_date'] = data.apply(lambda row : difference_two_datetimes(row['date'], date), axis = 1)
    # finds closest time
    # data[(data['diff_date'] == data['diff_date'].min()) & (data['segment_id']==origin_stop)]

    # find segment corresponding to origin stop in corresponding time
    # compute all the segments to the destination_stop
    # add travel_time of actual segment to actual_time
    # find segment with new time and corresponding to next segment in the route
    if info:
        print(
            "------Travel time between {} and {}------".format(
                origin_stop, destination_stop
            )
        )

    segments_list = compute_route(origin_stop, destination_stop)
    evolution_travel_times = []

    start_time = date
    # time = date
    total_travel_time = 0

    for s in range(len(segments_list)):
        data_segment = data[(data["segment_id"] == segments_list[s])].copy()
        # data_segment = data_segment.copy()
        data_segment["diff_date"] = data_segment.apply(
            lambda row: difference_two_datetimes(row["date"], date), axis=1
        )

        segment = data_segment[
            (data_segment["segment_id"] == segments_list[s])
            & (data_segment["diff_date"] == data_segment["diff_date"].min())
        ]  # what if empty?

        if info:
            print(
                "- Segment {} at tod {} (time: {})".format(
                    segments_list[s], segment.tod.values[0], segment.date.values[0]
                )
            )
        if info:
            print(
                "--- Diff with corresponding original time: {:.2f}".format(
                    segment.diff_date.values[0]
                )
            )
        total_travel_time += segment.travel_time.values[0]
        evolution_travel_times.append(total_travel_time)
        date = date + timedelta(seconds=int(segment.travel_time.values[0]))
        if info:
            print(
                "-- Travel time: {:.2f} ({})".format(
                    segment.travel_time.values[0],
                    date
                    + timedelta(
                        seconds=int(total_travel_time - segment.diff_date.values[0])
                    ),
                )
            )
        if info:
            print("-- Total travel time: {:.2f}".format(total_travel_time))
        if info:
            print("\n")

        # recompute difference between times, to find the closest
        # data['diff_date'] = data.apply(lambda row : difference_two_datetimes(row['date'], time), axis = 1)

    total_travel_time -= segment.travel_time.values[
        0
    ]  # last segment's time corresponds to time in stop, bus already arrived

    end_time = start_time + timedelta(seconds=int(total_travel_time))
    # end_time = segment.date.values[0]
    if info:
        print(
            "{}->{} took {} seconds. Starting at {}, the time of arrival to {} was {}".format(
                origin_stop,
                destination_stop,
                total_travel_time,
                start_time,
                destination_stop,
                end_time,
            )
        )

    return end_time, total_travel_time, evolution_travel_times

    # start_time = data[(data['segment_id']==origin_stop) & data['diff_date']==data['diff_date'].min()].date
    # end_time = data[data['segment_id']==destination_stop].date

    # return difference_two_datetimes(end_time, start_time)

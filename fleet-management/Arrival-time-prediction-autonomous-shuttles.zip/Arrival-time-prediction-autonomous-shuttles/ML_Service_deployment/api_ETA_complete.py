from fastapi import FastAPI
from google.cloud import storage
from pydantic import BaseModel
import torch
import io
import dateutil.parser
import numpy as np
from meteostat import Hourly
from datetime import timedelta
from torch_geometric.data import Data
import torch.nn.functional as F

from models.gcn_model import NodeEncodedGCN

BUCKET_NAME = "bucketshow"
MODEL_TT_FILE = "LINKOPING/model_tt.ckpt"
MODEL_DT_FILE = "LINKOPING/model_dt.ckpt"
LAGS_TT_FILE = "LINKOPING/lags_tt.pt"
LAGS_DT_FILE = "LINKOPING/lags_dt.pt"

client = storage.Client()
bucket = client.get_bucket(BUCKET_NAME)

blob = bucket.get_blob(MODEL_TT_FILE)
model_tt = blob.download_as_string()
# because model downloaded into string, need to convert it back
buffer = io.BytesIO(model_tt)
model_tt = NodeEncodedGCN.load_from_checkpoint(buffer)

blob = bucket.get_blob(MODEL_DT_FILE)
model_dt = blob.download_as_string()
# because model downloaded into string, need to convert it back
buffer = io.BytesIO(model_dt)
model_dt = NodeEncodedGCN.load_from_checkpoint(buffer)

app = FastAPI()

blob2 = bucket.get_blob(LAGS_TT_FILE)
b = blob2.download_as_string()
lags_tt_buffer = io.BytesIO(b)
lags_tt = torch.load(lags_tt_buffer)

blob2 = bucket.get_blob(LAGS_DT_FILE)
b = blob2.download_as_string()
lags_tt_buffer = io.BytesIO(b)
lags_dt = torch.load(lags_tt_buffer)


@app.get("/")
def read_root():
    return {"Hello": "World"}


class Location(BaseModel):
    timestamp: str
    lat: float
    lon: float
    last_stop: int


class SHOWDataset(Data):
    """Torch Geometric dataset extended with graph level feature"""

    def __init__(
        self,
        x,
        edge_index,
        global_feat,
        node_encoding,
        **kwargs,
    ) -> None:
        super().__init__(x=x, edge_index=edge_index, **kwargs)
        self.global_feat = global_feat
        self.node_encoding = node_encoding


@app.post("/predict_bus")
def ETA_pred(location: Location):
    route1 = {0: 2, 2: 1, 1: 7, 7: 5, 5: 3, 3: 6, 6: 4, 4: 0}

    route2 = {0: 2, 2: 1, 1: 7, 7: 5, 5: 3, 3: 6, 6: 9, 9: 10, 10: 13, 13: 8, 8: 12, 12: 11, 11: 14, 14: 4, 4: 0}

    timestamp = dateutil.parser.parse(location.timestamp)
    weekday = timestamp.weekday()
    time_of_day = timestamp.replace(minute=timestamp.minute // 15 * 15, second=0, microsecond=0).time()
    dow_sin = np.sin(2 * np.pi * weekday / 6)
    dow_cos = np.cos(2 * np.pi * weekday / 6)
    max_tod = 95  # it must be the maximum possible value (23:45:00, not the maximum registered value)
    tod_encoded = (time_of_day.hour * 4) + (time_of_day.minute // 15)
    tod_sin = np.round(np.sin(2 * np.pi * tod_encoded / max_tod), decimals=6)
    tod_cos = np.round(np.cos(2 * np.pi * tod_encoded / max_tod), decimals=6)
    weather_data = (
        Hourly("02562", timestamp, timestamp + timedelta(minutes=60)).fetch().reset_index()
    )  # gets a dataset with weather info (1 hour intervals) at station number 02562 - Linköping
    # weather_data = weather_data[["time", "temp", "prcp", "snow", "wspd"]]
    weather_data = weather_data[["temp", "prcp", "wspd"]]
    weather_data = weather_data.fillna(0)
    weather_data = torch.tensor(weather_data.to_numpy(), dtype=torch.float)
    time = torch.Tensor([dow_sin.item(), dow_cos.item(), tod_sin.item(), tod_cos.item()])
    # time = torch.Tensor(time, dtype=torch.float)

    lags_tt_t, weather_data, _ = model_tt.transform.transform(
        his=lags_tt, weather=weather_data, target=torch.Tensor([0, 0])
    )

    global_feat = torch.cat([time, weather_data.squeeze()], dim=0)

    edge_index_segments = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 5, 15, 13],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 13, 15, 13, 0],
        ]
    )

    edge_index_stops = torch.tensor(
        [[0, 2, 1, 7, 5, 3, 6, 9, 10, 13, 8, 12, 11, 4, 14, 6], [2, 1, 7, 5, 3, 6, 9, 10, 13, 8, 12, 11, 14, 0, 4, 4]]
    )

    segment_ids = [
        "0_2",
        "2_1",
        "1_7",
        "7_5",
        "5_3",
        "3_6",
        "6_9",
        "9_10",
        "10_13",
        "13_8",
        "8_12",
        "12_11",
        "11_14",
        "4_0",
        "14_4",
        "6_4",
    ]

    segment_lookup = {k: v for v, k in enumerate(segment_ids)}

    model_input_tt = {
        "x": lags_tt_t,
        "global_feat": global_feat,
        "edge_index": edge_index_segments,
        "node_encoding": F.one_hot(torch.tensor(list(range(16)))),
    }
    model_input = SHOWDataset(**model_input_tt)
    pred_tt = model_tt.predict_step(batch=model_input, batch_idx=0)

    lags_dt_t, weather_data, _ = model_dt.transform.transform(
        his=lags_dt, weather=weather_data, target=torch.Tensor([0, 0])
    )

    global_feat = torch.cat([time, weather_data.squeeze()], dim=0)

    model_input_dt = {
        "x": lags_dt_t,
        "global_feat": global_feat,
        "edge_index": edge_index_stops,
        "node_encoding": F.one_hot(torch.tensor(list(range(15)))),
    }
    model_input = SHOWDataset(**model_input_dt)
    pred_dt = model_dt.predict_step(batch=model_input, batch_idx=0)

    pred_ETA_1 = [0] * 15
    pred_tt = pred_tt.tolist()
    pred_dt = pred_dt.tolist()
    current_stop = location.last_stop
    stops_visited = set()
    time = timestamp
    if current_stop in route1.keys():
        while current_stop not in stops_visited:
            stops_visited.add(current_stop)
            last_stop = current_stop
            current_stop = route1[current_stop]
            pred_ETA_1[current_stop] = time + timedelta(seconds=pred_tt[segment_lookup[f"{last_stop}_{current_stop}"]])
            time += timedelta(seconds=pred_tt[segment_lookup[f"{last_stop}_{current_stop}"]]) + timedelta(
                seconds=pred_dt[current_stop]
            )

    time = timestamp
    stops_visited = set()
    current_stop = location.last_stop
    pred_ETA_2 = [0] * 15
    while current_stop not in stops_visited:
        stops_visited.add(current_stop)
        last_stop = current_stop
        current_stop = route2[current_stop]
        pred_ETA_2[current_stop] = time + timedelta(seconds=pred_tt[segment_lookup[f"{last_stop}_{current_stop}"]])
        time += timedelta(seconds=pred_tt[segment_lookup[f"{last_stop}_{current_stop}"]]) + timedelta(
            seconds=pred_dt[current_stop]
        )
    return pred_ETA_1, pred_ETA_2

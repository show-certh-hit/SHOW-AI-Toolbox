import pandas as pd

from geopy import distance
import datetime
import dateutil.parser

import matplotlib.pyplot as plt

import folium
from branca.element import Figure
import branca.colormap as cm

from constants import STOPS_LONG

# --------------BASIC FUNCTIONS------------------

# distance beetween two points
# https://stackoverflow.com/questions/19412462/getting-distance-between-two-points-based-on-latitude-longitude
"""
Computes new columns:
    *'dist_last_point' indicates the distance traveled since the previous point (in m). 
      Distances calculated using WGS-84 ellipsoid model of the Earth.
    *'traveled_dist' indicates the total distance traveled since the beginning (in m)
    *'speed_m/s' indicates the computed speed between two points distance(actual_point,prev_point)/time (in m/s)
    *'speed_km/h' speed (in km/h)
    *'speed_miles/h' (in miles/h)
    *'total_travel_time' total_travel_time in each point since the start of the journey (in seconds)
    
Saves the new columns in the dataset passed as parameter.

TO DO: Make this in a vectorised way - not possible since values from previous rows are needed -> maybe possible -> DONE

data['traveled_distance'] = data.apply(lambda row : distance.distance(start,(row['lat'],row['lon'])).m, axis = 1)
This computes the distance referred to the first point, but not always is correct
"""


def compute_dist_speed(data):
    # shifting data from previous points - column moves 1 row forward, first row will be empty
    data["prev_lat"] = data["lat"].shift(1)
    data["prev_lon"] = data["lon"].shift(1)
    data["prev_last_seen"] = data["last_seen"].shift(1)

    data.loc[0, "prev_lat"] = data.loc[0, "lat"]
    data.loc[0, "prev_lon"] = data.loc[0, "lon"]

    # performing operations
    data["dist_last_point"] = data.apply(
        lambda row: distance.distance(
            (row["lat"], row["lon"]), (row["prev_lat"], row["prev_lon"])
        ).m,
        axis=1,
    )
    data["traveled_dist"] = data["dist_last_point"].cumsum()
    data["time_last_point"] = data.apply(
        lambda row: (row["last_seen"] - row["prev_last_seen"]).seconds, axis=1
    )
    data["speed_m/s"] = data.apply(
        lambda row: (
            row["dist_last_point"] / row["time_last_point"]
            if row["time_last_point"] > 0
            else 0
        ),
        axis=1,
    )  # FIX THIS! 0 when movement in the same time, should be speed from previous point
    data["total_travel_time"] = data["time_last_point"].cumsum()
    data["speed_km/h"] = data["speed_m/s"] * 3.6

    # drop columns created for the operations
    data = data.drop(
        columns=["prev_lat", "prev_lon", "prev_last_seen", "time_last_point"]
    )
    return data


"""
Transforms the different attributes of the data:
'last_seen': Transforms the 'last_seen' (type object) to datetime, in order to be able to make operations with it
'speed': Transforming the negative values of the oginal attribute speed in positive values. Negative values represent that the bus goes in reverse
Computes the fields described in compute_dist_speed
"""


def transform_data(data, speeds=True):
    data["last_seen"] = data.apply(
        lambda row: dateutil.parser.parse(row["last_seen"]), axis=1
    )
    data["speed"] = data["speed"].fillna(
        0
    )  # in vehicle_1 when it is not moving, speed is None
    data["speed"] = data["speed"].abs()
    if speeds:
        data = compute_dist_speed(data)
    return data


# stats about the journey
def journey_stats(data):
    print(
        "Total traveled time: {} ".format(
            datetime.timedelta(seconds=data["total_travel_time"].max())
        )
    )
    print(
        "Computed total traveled distance: {0:.2f} (m)".format(
            data["traveled_dist"].max()
        )
    )
    print(
        "Mileage total traveled distance: {0:.2f} (m)".format(
            (data["mileage"].max() - data["mileage"].min()) * 1000
        )
    )
    print("Average speed: {0:.2f} (km/h)".format(data["speed_km/h"].mean()))
    print(
        "Computed average speed: {0:.2f} (km/h)".format(
            (data["traveled_dist"].max() / data["total_travel_time"].max())
            * 3600
            / 1000
        )
    )


"""
Representation of the bus speeds
"""


def speeds_graphs(data, kmh=False):
    if kmh:
        speed_data = data["speed_km/h"]
        label = "Speed (km/h)"
    else:
        speed_data = data["speed_m/s"]
        label = "Speed (m/s)"

    fig, (ax1, ax2) = plt.subplots(2, figsize=(30, 15))

    # ax1.plot(data['total_travel_time'], data['speed'])
    ax1.plot(data["last_seen"], data["speed"])
    # ax1.set_xlabel(' Total travel time (ms)', fontsize=18)
    ax1.set_xlabel("Time of the day (day - hour)", fontsize=18)
    ax1.set_ylabel("Speed (m/s???)", fontsize=18)
    ax1.grid()

    # ax2.plot(data['total_travel_time'], speed_data)
    ax2.plot(data["last_seen"], speed_data)
    # ax2.set_xlabel('Total travel time (ms)', fontsize=18)
    ax2.set_xlabel("Time of the day (day - hour)", fontsize=18)
    ax2.set_ylabel(label, fontsize=18)
    ax2.grid()

    # if using this part, add a thir ax3 at the beginning of the subplot
    # ax3.plot(data['total_travel_time'], data['speed_km/h'])
    # ax3.set_xlabel(' Total travel time (ms)', fontsize=18)
    # ax3.set_ylabel('Speed (km/h)', fontsize=18)
    # ax3.grid()

    fig.suptitle("Speeds", size=30)
    fig.tight_layout()
    plt.show()


"""
Represents data in the a map, taking also into account the speed in each moment. 
"""


def map_representation(data, name="bus", stops=False):
    CENTER_COORD = [58.395493, 15.580531]

    # necessary data for the representation
    coords = data[["lat", "lon"]].values.tolist()
    speeds = data["speed_km/h"].values.tolist()
    max_speed = data["speed_km/h"].max()

    # creating the map
    fig = Figure(width=900, height=500)
    m = folium.Map(location=CENTER_COORD, zoom_start=15)
    fig.add_child(m)

    # adding extra layers
    # folium.TileLayer('Stamen Terrain').add_to(m)
    # folium.TileLayer('Stamen Toner').add_to(m)
    folium.TileLayer("cartodbpositron").add_to(m)

    # adding a layer with a route
    f1 = folium.FeatureGroup(name)

    colormap = cm.LinearColormap(
        colors=["red", "yellow", "green"],
        index=[0, max_speed * 0.5, max_speed],
        vmin=0,
        vmax=max_speed,
        caption="Speed of the {} (km/h)".format(name),
    )

    # represents the route in one colour
    # folium.vector_layers.PolyLine(coords,popup='<b>Path of Vehicle_1</b>',tooltip='Vehicle_1',color='blue',weight=5).add_to(f1)
    folium.ColorLine(
        positions=coords, colors=speeds, weight=5, colormap=colormap
    ).add_to(f1)
    f1.add_to(m)
    colormap.add_to(m)

    if stops:
        f2 = folium.FeatureGroup("Bus stops")

        for key, value in STOPS_LONG.items():
            folium.Marker(
                location=[value["coords"][0], value["coords"][1]], popup=value["name"]
            ).add_to(f2)

        f2.add_to(m)

    folium.LayerControl().add_to(m)

    return m  # shows the map

    # m.save("route_map.html")


# ---------------DELETE ERROR POINTS-----------------
"""
Keeps the points in which the speed (km/h) is lower than 90 km/h and the distance from the last point is less than 100 m. 
Like this, the points in which the GPS signal moves from the true position to a wrong one are deleted, but it is also necessary 
to delete the points in the wrong position but without any changes (wrong position and speed 0, so distance from previous 
point is also 0) -> The function deletes the values in which the bus is stopped -> the correct points in which the bus is 
stopped (e.g. bus stop or traffic lights) are also deleted, but this should not influence our data, since the times from one 
point to another are going to be the same 

Possible solution: take index of the points of the wrong GPS data, save in a list, for each coordinate of the list, take
only the points where the coordinates are different to the wrong ones. -> DONE

With the first approach we end having 20125 rows, and with the new approach we end having 20625 rows (with this specific file)
"""


def delete_error_points(data):
    # ----Previous version----
    # data = data[(data['dist_last_point']>0) & (data['dist_last_point']<100) & (data['speed_km/h']<90)]

    # saves lat and lon of the points with speed > 60 km/h or distance to last point > 100
    list_wrong_coord = data[
        (data["speed_km/h"] > 60) | (data["dist_last_point"] > 100)
    ][["lat", "lon"]].values.tolist()

    if len(list_wrong_coord) > 0:
        list_wrong_coord = [
            tuple(l) for l in list_wrong_coord
        ]  # transforms list of list to list of tuples (lat, lon)

        # keeps rows in which lat or lon are different than values in the list
        # NOTE: if the lat/lon of a point is the same, that row also gets deleted...
        condition = (~data["lat"].isin([i[0] for i in list_wrong_coord])) & (
            ~data["lon"].isin([j[1] for j in list_wrong_coord])
        )
        data = data[condition]
        data = data.reset_index(drop=True)  # to iterate properly later
        data = compute_dist_speed(data)  # recompute the values of speed and distances

    return data


# ---------------RESAMPLE DATA-----------------
"""
Resamples the dataset in order to reduce the frequency of the data to improve the accuracy of 
computed speed and visualizations. 
Makes use of the function resample from pandas, keeping the first element of each group, and deleting samples 
without records (moments of lost connection between bus and GPS).
"""


def resample(data, freq="2s"):
    data_resampled = data.resample(
        freq, on="last_seen"
    ).first()  # downsampling keeping the first element of each group
    data_resampled = data_resampled[
        (data_resampled["lat"].notna()) & (data_resampled["lon"].notna())
    ].reset_index(
        drop=True
    )  # deleting for lost connection with the bus and reseting index to iterate later
    data_resampled = compute_dist_speed(
        data_resampled
    )  # recomputes the fields with speeds and distances
    return data_resampled


# losing accuracy in the data here? -> no, it keeps the first value in each of the groups

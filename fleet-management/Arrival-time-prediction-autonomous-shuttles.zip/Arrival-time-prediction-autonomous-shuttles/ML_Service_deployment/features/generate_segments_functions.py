from stops_info_functions import *
from processing_functions import *
from logging_functions import *
from constants import DICT_TIME_ENCODING

from datetime import timedelta
from sklearn.preprocessing import OneHotEncoder

from meteostat import Hourly

import re
import glob

logger = set_up_logger()

#########################################
# -------------MAIN FUNCTION-------------#
#########################################
"""
Taking a dataset with GPS coordinates and its timestamps, generates a new dataset with the segments and time spent in 
each segment.
"""


def generate_dataset_from_data(data):

    # groups by 'in_stop', 'next_stop', 'n_round' keeping the first and last value of time in the segment (start_time and end_time) and their index in the original dataset
    segments = (
        data.groupby(["in_stop", "next_stop", "n_round"])
        .last_seen.agg(
            [
                "min",
                ("id_min", lambda x: x.idxmin()),
                "max",
                ("id_max", lambda x: x[::-1].idxmax()),
            ]
        )
        .rename(columns={"min": "start_time", "max": "end_time"})
    )

    columns = ["date", "segment_id", "travel_time"]
    segments_data = []

    # loops over rows in group by
    for start, end, n_round in segments.index.tolist():
        row = segments.loc[start].loc[end].loc[n_round]
        date = row["start_time"]
        segment_id = get_segment_id(row["id_min"], row["id_max"], data)
        travel_time = (row["end_time"] - row["start_time"]).seconds
        segments_data.append([date, segment_id, travel_time])

    segments_dataset = pd.DataFrame(data=segments_data, columns=columns)

    if len(segments_dataset) > 0:
        segments_dataset["dow"] = segments_dataset.apply(
            lambda row: day_of_week(row["date"]), axis=1
        )
        segments_dataset["dow_day"] = segments_dataset.apply(
            lambda row: day_of_week(row["date"], False), axis=1
        )
        segments_dataset["tod"] = (
            (
                segments_dataset["date"]
                - pd.TimedeltaIndex(segments_dataset["date"].dt.minute % 15, "m")
            )
            - pd.TimedeltaIndex(segments_dataset["date"].dt.second, "s")
        ).dt.time

    return segments_dataset


##############################################################
# -------FUNCTION TO CHECK THE CORRECTNESS OF THE DATASET----#
##############################################################
"""
Returns TRUE if a segment is possible and FALSE if not. 
Possible segments are the ones in which the the stops are consecutive (e.g. s0_s1, s7a_s8a, s9_s8b...)
Examples of wrong segments: s2_s4, s8b_s10, s0_No in stop. This segments sometimes appear because 
the bus is not detected in the stop due to the inevitable errors in the GPS location.
"""


def segment_is_correct(segment):
    stops_in_segment = segment.split("_")
    correct = True

    # print(stops_in_segment)

    # if there is a string that is not a stop id is not correct, e.g. s10_No in stop
    if not all(stop in STOPS_LONG for stop in stops_in_segment):
        correct = False
        # print('Wrong stop id')

    # if segment between two stops, check that consecutive stops
    if len(stops_in_segment) > 1:
        expected_next_stop = next_stop(stops_in_segment[0])
        correct = expected_next_stop == stops_in_segment[1]

        # special cases when shortest route is allowed
        if (stops_in_segment[0] == "s6") & (stops_in_segment[1] == "s10"):
            correct = True

        # print('Not consecutive') if not correct else print('Consecutive')
    return correct


def check_segments(segments_data):
    n_samples_original = len(segments_data)
    segments_data["correct_segment"] = segments_data.apply(
        lambda row: segment_is_correct(row["segment_id"]), axis=1
    )
    segments_data = segments_data[segments_data["correct_segment"] == True]
    segments_data = segments_data.drop(columns=["correct_segment"])
    n_samples_later = len(segments_data)
    logger.info(
        "---Deleted {} invalid segments".format(n_samples_original - n_samples_later)
    )
    return segments_data


############################################################################
# ----FUNCTIONS TO AUTOMATE THE PROCESS OF GENERATING THE SEGMENTS DATASET--#
############################################################################
"""
Load and processes data from one file generating the corresponding dataset with the information 
about the segments. It is important to distinguish to which vehicle the file corresponds, since 
the fomats are different and need to be adapted. After that, 'transform_data()' is used to adapt 
data formats, 'add_stops_info()' computes actual and next bus stop in every moment and 
'generate_dataset_from_data()' obtains information for every segment and moment of the day that 
is available in the original file.

Returns: dataset with segments and travel time in each segments computed from data.
"""


def load_and_process_file(path):
    vehicle_number = int(
        re.search(r"\d+", path).group()
    )  # recognizes the first number from the path, in this case is enough
    logger.info(
        "Processing {}. Corresponding to vehicle {}".format(path, vehicle_number)
    )

    df = pd.read_csv(path, delimiter=",", header=0)

    if vehicle_number == 1:
        logger.info("--Renaming columns vehicle 1")
        df = df.rename(
            columns={
                "record_date": "last_seen",
                "geo_lat": "lat",
                "geo_lon": "lon",
                "speed_value": "speed",
            }
        )

    logger.info("--Transforming data")
    df = transform_data(
        df, speeds=False
    )  # not necessary to compute speeds for segments
    logger.info("--Adding stops info")
    df = add_stops_info(df)
    logger.info("--Generating segments dataset")
    segments_data = generate_dataset_from_data(df)
    # logger.info('--Checking valid segments')
    # segments_data = check_segments(segments_data)
    logger.info("--File processed successfully")
    return segments_data


"""
Function used to process all data files from the folder where they are stored. Each file is transfomed 
using 'load_and_process_file()' and the obtained dataset with segments is saved in a list. Finally all 
the datasets are concatened in one dataset with all the segments from different days.

Returns: segments dataset with information from all the days available in the raw data files.
"""


def process_all_files(
    folder_path="C:/Users/kubap/Desktop/DTU/Master_Thesis/Data/linkoping-vehicle-",
    month=None,
    year=None,
    vehicle=None,
    file_name_out="SegmentsDataset",
):
    if ((month != None) and (year != None)) and (vehicle != None):
        path = (
            folder_path + vehicle + "-" + "*-" + month + "-" + year + ".csv"
        )  # all the files from that vehicle in specified month and year
    elif ((month == None) or (year == None)) and (vehicle != None):
        path = (
            folder_path + vehicle + "*.csv"
        )  # all the files corresponding to the vehicle
    elif ((month != None) and (year != None)) and (vehicle == None):
        path = (
            folder_path + "*" + month + "-" + year + ".csv"
        )  # all the files corresponding to the month and year
    else:
        path = folder_path + "*.csv"  # all the files

    logger.info("-Loading files from path: {}".format(path))
    files = glob.glob(path)

    segments_dataset = pd.DataFrame()
    content = []

    for file in files:
        data_from_file = load_and_process_file(file)
        content.append(data_from_file)

    logger.info("-Merging data in one dataset")
    segments_dataset = pd.concat(content, ignore_index=True)

    logger.info("-Saving dataset in file")
    segments_dataset.to_excel(
        "C:/Users/kubap/Desktop/DTU/Master_Thesis/Data/{}.xlsx".format(file_name_out),
        index=False,
    )
    logger.info("-XLSX saved as {}.xlsx".format(file_name_out))
    segments_dataset.to_csv(
        "C:/Users/kubap/Desktop/DTU/Master_Thesis/Data/{}.csv".format(file_name_out),
        index=False,
    )
    logger.info("-CSV saved as {}.csv".format(file_name_out))

    logger.info("-Transforming dataset")
    # segments_dataset['date'] = segments_dataset.apply(lambda row : dateutil.parser.parse(row['date']), axis = 1)

    return segments_dataset


############################################
# ------------Additional functions----------#
############################################
"""
Returns a string that combines the day of the week and the time of the day. Field use for representation/graphs.
"""


def dow_tod(dow_day, tod):
    return dow_day + " " + str(tod)


def dow_tod_dataset(segments_dataset):
    segments_dataset["dow_tod"] = segments_dataset.apply(
        lambda row: dow_tod(row["dow_day"], row["tod"]), axis=1
    )
    return segments_dataset


#############################################
# -------Inspection of the dataset--------#
#############################################
"""
Returns two datasets: one containing only the stops and the other with the segments between stops
"""


def get_stops_and_segments(segments_dataset):
    mask_segments = segments_dataset["segment_id"].str.contains(
        "_"
    )  # all values containing '_' -> segments between stops

    stops = segments_dataset[~mask_segments]  # if it doesnt contain '_' is a stop
    segments = segments_dataset[mask_segments]
    return stops, segments


"""
Computes statistical values needed for the IQR of each segment.
"""


def segments_info(data):
    if "travel_time" in data.columns:
        attribute = "travel_time"
    else:
        attribute = "y_test"

    cut_off_factor = 1.5
    segments_info = data.groupby("segment_id")[attribute].agg(
        [
            "mean",
            "min",
            "max",
            "std",
            ("q25", lambda x: np.percentile(x, 25)),
            ("q50", lambda x: np.percentile(x, 50)),
            ("q75", lambda x: np.percentile(x, 75)),
            ("q95", lambda x: np.percentile(x, 95)),
        ]
    )
    # compute interquantile ranges
    segments_info["iqr"] = segments_info["q75"] - segments_info["q25"]
    # compute outliers cut offs
    segments_info["lower"] = np.maximum(
        segments_info["q25"] - (cut_off_factor * segments_info["iqr"]),
        segments_info["min"],
    )
    segments_info["upper"] = np.minimum(
        segments_info["q75"] + (cut_off_factor * segments_info["iqr"]),
        segments_info["max"],
    )
    return segments_info


"""
Creates a boxplot in which it is possible to observe outliers and distribution of the travel_time
in each segment of the dataset
"""


def boxplot(data, save=False):
    ax = data.boxplot(
        "travel_time", by="segment_id", figsize=(30, 15), fontsize=20, rot=45
    )
    plt.xlabel("segment_id", fontsize=23)
    plt.ylabel("travel_time (s)", fontsize=23)
    plt.suptitle("")
    plt.title("")
    if save:
        plt.savefig("C:/Users/kubap/Desktop/screenshots/boxplot_segments.png")


"""
Gets the number of the month from date
"""


def get_month_from_date(date):
    datem = datetime.datetime.strptime(str(date), "%Y-%m-%d %H:%M:%S")
    # day, month, year = datem.day, datem.month, datem.year
    return datem.month


"""
Makes possible to visualize evolution in travel_time in a specific segment in different periods of time. Available periods are:
- week: weeks of the year. Each week of the year is identified with an integer, starting with 0 #see weeks in the year here: https://www.epochconverter.com/weeks/2022
- dates: period of time between two dates. The parameter that should be used is a tuple formed by the two dates.
- month: month of the year. Each month is identified with an integer, starting with 1.

Additional options:
- save: boolean that indictaes if the graph should be saved as PNG.
"""


def evolution_travel_time(
    segments_dataset, segment, week=None, dates=None, save=False, month=None
):
    # computing extra fields needed to filter the data
    segments_dataset["dow_tod"] = dow_tod_dataset(segments_dataset)
    segments_dataset["month"] = segments_dataset.apply(
        lambda row: get_month_from_date(row["date"]), axis=1
    )
    segments_dataset["week"] = segments_dataset.apply(
        lambda row: row["date"].isocalendar()[1], axis=1
    )  # returns week of the year to which belongs the date)

    # prepraing data that will be plotted
    if month != None:
        condition = (segments_dataset["segment_id"] == segment) & (
            segments_dataset["month"] == month
        )
        message = "Travel time in segment {} in month {}".format(segment, month)
    elif dates != None:
        condition = (
            (segments_dataset["date"] >= dates[0])
            & (segments_dataset["date"] <= dates[1])
            & (segments_dataset["segment_id"] == segment)
        )
        message = "Travel time in segment {} in between dates {} and {}".format(
            segment, dates[0], dates[1]
        )
    elif week != None:
        condition = (segments_dataset["week"] == week) & (
            segments_dataset["segment_id"] == segment
        )
        message = "Travel time in segment {} in week {}".format(segment, week)
    else:
        condition = segments_dataset["segment_id"] == segment
        message = "Travel time in segment {}".format(segment)

    # plotting
    segments_dataset[condition].sort_values(by=["dow", "tod"]).plot.line(
        x="dow_tod", y="travel_time", figsize=(30, 10), fontsize=14, marker="o"
    )

    plt.title(message, fontsize=18)
    plt.xlabel("Day of the week : time of the day", fontsize=18)
    plt.ylabel("travel_time in segment {} (s)".format(segment), fontsize=18)

    segments_dataset = segments_dataset.drop(columns=["month", "week"])

    if save:
        plt.savefig(
            "C:/Users/kubap/Desktop/screenshots/time_series_segment_{}.png".format(
                segment
            )
        )


#####################################################
# -----------------OUTLIERS REMOVAL------------------#
#####################################################
"""
Identifies and removes all the outliers from the dataset. The following cases are considered outliers:
- Samples with negative travel time or 0, since the travel time of a bus in a segment cannot be 0 or lower.
- Samples in s10_s0 contain moments in which the bus has stopped in the parking in order to recharge the batteries. These data cannot be considered
  by the model, since it is not a realistic representation of the travel time in the segment
- Samples above the upper limit using IQR (Interquantile Range Method). Samples below the lower limit are not considered outliers, since they 
  correspond to moments in which the bus has passed close to the stop but without stopping on it
"""


def remove_outliers(data):
    print("Initial number of samples: {}".format(data["travel_time"].count()))

    ######## 1) Removing outliers manually ###########################

    # samples with travel time 0 are also outliers (wrong bus' stop position?), since the travel time of a bus in segment can not be 0
    # data['outlier_0'] = data.apply(lambda row : row['travel_time'] == 0, axis=1)
    ##THIS SAMPLES SHOULD BE TRANSFORMED TO TRAVEL_TIME 1 BECAUSE MAYBE THEY MOSTLY CORRESPOND TO SITUATIONS IN WHICH THE BUS DOESNT STOP!!
    print(
        "Transforming {} samples with travel_time 0.".format(
            data[(data["travel_time"] == 0) & (data["segment_id"] != "s0")][
                "travel_time"
            ].count()
        )
    )
    data.loc[
        (data["travel_time"] == 0) & (data["segment_id"] != "s0"), "travel_time"
    ] = 1

    data["outlier_s0_0"] = data[(data["segment_id"] == "s0")].apply(
        lambda row: row["travel_time"] == 0, axis=1
    )

    # outliers in segment s10_s0 should be removed manually, since there is not any pattern to detect them.
    # They correspond to the samples in which the bus stops in the parking in between the stop s10 and s0, so it does not correspond to the real travel time.
    # all travel times above 650 s in the segment s10_s0 will be considered outliers
    data["outlier_s10_s0"] = data[(data["segment_id"] == "s10_s0")].apply(
        lambda row: row["travel_time"] > 650, axis=1
    )

    print(
        "Removing {} outliers with travel_time 0 in segment s0.".format(
            data[(data["travel_time"] == 0) & (data["segment_id"] == "s0")][
                "travel_time"
            ].count()
        )
    )
    print(
        "Removing {} outliers corresponding to parking times in s10_s0 segment.".format(
            data[(data["outlier_s10_s0"] == True)]["travel_time"].count()
        )
    )

    data = data[
        (data["outlier_s10_s0"] != True) & (data["outlier_s0_0"] != True)
    ]  # oulier_s10_s0 can be True, False or None, we want to remove Trues

    ######## 2) Removing outliers automatically - IQR method #########

    # IMPORTANT! This step must be made after removing manually the outliers since the iqr, lower and upper values change
    # after removing some samples manually -> recompute iqr_stats
    iqr_stats = segments_info(data)

    # considering outliers the samples with travel_time above upper - the ones under the lower limit are not outliers since they can correspond to real data in which a bus doesnt stops
    data["outlier_iqr"] = data.apply(
        lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper, axis=1
    )

    print(
        "Removing {} outliers detected by IQR method.".format(
            data[(data["outlier_iqr"] == True)]["travel_time"].count()
        )
    )
    data = data[data["outlier_iqr"] == False]

    data = data.drop(columns=["outlier_iqr", "outlier_s10_s0", "outlier_s0_0"])
    data = data.reset_index(drop=True)

    print(
        "After removing outliers, the dataset set is formed by {} samples.".format(
            data["travel_time"].count()
        )
    )
    return data


#############################################
# ------------WEATHER INFO-------------------#
#############################################
# description of the dataset: https://dev.meteostat.net/python/hourly.html#example

# Mapping condiction code ('coco') - https://dev.meteostat.net/formats.html#meteorological-data-units
condition_code = {
    0: "Unknown",
    1: "Clear",
    2: "Fair",
    3: "Cloudy",
    4: "Overcast",
    5: "Fog",
    6: "Freezing Fog",
    7: "Light Rain",
    8: "Rain",
    9: "Heavy Rain",
    10: "Freezing Rain",
    11: "Heavy Freezing Rain",
    12: "Sleet",
    13: "Heavy Sleet",
    14: "Light Snowfall",
    15: "Snowfall",
    16: "Heavy Snowfall",
    17: "Rain Shower",
    18: "Heavy Rain Shower",
    19: "Sleet Shower",
    20: "Heavy Sleet Shower",
    21: "Snow Shower",
    22: "Heavy Snow Shower",
    23: "Lightning",
    24: "Hail",
    25: "Thunderstorm",
    26: "Heavy Thunderstorm",
    27: "Storm",
}


def add_weather(data):
    data["date_1h"] = data.apply(
        lambda row: row["date"].replace(minute=0, second=0, microsecond=0), axis=1
    )  # identifying 1 hour intervals in the data
    start = data.date.min() - timedelta(days=1)
    end = data.date.max() + timedelta(days=1)

    weather_data = (
        Hourly("02562", start, end).fetch().reset_index()
    )  # gets a dataset with weather info (1 hour intervals) at station number 02562 - Linköping
    weather_data = weather_data[["time", "temp", "prcp", "snow", "wspd", "coco"]]
    weather_data["snow"] = weather_data["snow"].fillna(0)

    weather_data["condition"] = weather_data.apply(
        lambda row: condition_code[row["coco"]], axis=1
    )

    data_with_weather = pd.merge(
        data, weather_data, how="left", left_on="date_1h", right_on="time"
    )  # left join adds weather to dataset. Join on 'date_1h' and 'time'
    data_with_weather = data_with_weather.drop(columns=["date_1h", "time"])
    return data_with_weather


#############################################
# -----------------ENCODING------------------#
#############################################
"""
Encodes the day of the week using a wo dimensional vector formed by the sine and cosine. Keeps cyclic nature.
"""


def encode_dow(data):
    data["dow"] = (
        data["dow"] + 1
    )  # necessary? why not change mapping days in day_of_week()?
    # max_dow = data['dow'].max()
    max_dow = 7  # it must be the maximum possible value, not the maximum registered

    data["dow_sin"] = np.sin(2 * np.pi * data["dow"] / max_dow)
    data["dow_cos"] = np.cos(2 * np.pi * data["dow"] / max_dow)
    return data


"""
Auxiliar function that creates a list of datetimes from start (datetime) to end (datetime) 
with intervals defined by delta
"""


def datetime_range(start, end, delta):
    current = start
    while current < end:
        yield current
        current += delta


"""
Encodes time of the day using sine and cosine, being able like this to keep its the cyclic nature 
"""


def encode_tod(data):
    # maps tod with the encoding value
    data["tod_encoded"] = data.apply(lambda row: DICT_TIME_ENCODING[row["tod"]], axis=1)

    # cyclic encoding with sine and cosine
    max_tod = DICT_TIME_ENCODING[
        "23:45:00"
    ]  # it must be the maximum possible value (23:45:00, not the maximum registered value)
    data["tod_sin"] = np.round(
        np.sin(2 * np.pi * data["tod_encoded"] / max_tod), decimals=6
    )
    data["tod_cos"] = np.round(
        np.cos(2 * np.pi * data["tod_encoded"] / max_tod), decimals=6
    )
    # data.drop(labels=['tod_encoded'])
    return data


"""
Prepares an encoder to bes use as One Hot Encoder with the categories including all the possible segments. Like this it is
possible to use the encoder several times and it is created only once, not every time that the encoding function is executed.
"""


def prepare_encoder(segments=False, weather=False):
    if segments:
        # segments = list(data['segment_id'].unique())
        segments = [
            "s0",
            "s0_s1",
            "s1",
            "s1_s2",
            "s2",
            "s2_s3",
            "s3",
            "s3_s4",
            "s4",
            "s4_s5",
            "s5",
            "s5_s6",
            "s6",
            "s6_s7a",
            "s7a",
            "s7a_s8a",
            "s8a",
            "s8a_s9",
            "s9",
            "s9_s8b",
            "s8b",
            "s8b_s7b",
            "s7b",
            "s7b_s10",
            "s10",
            "s10_s0",
            "s6_s10",
        ]
        segments.sort()
        oh_encoder = OneHotEncoder(categories=[segments], sparse=False)
    elif weather:
        # Mapping condiction code ('coco') - https://dev.meteostat.net/formats.html#meteorological-data-units
        weather_conditions = [
            "Unknown",
            "Clear",
            "Fair",
            "Cloudy",
            "Overcast",
            "Fog",
            "Freezing Fog",
            "Light Rain",
            "Rain",
            "Heavy Rain",
            "Freezing Rain",
            "Heavy Freezing Rain",
            "Sleet",
            "Heavy Sleet",
            "Light Snowfall",
            "Snowfall",
            "Heavy Snowfall",
            "Rain Shower",
            "Heavy Rain Shower",
            "Sleet Shower",
            "Heavy Sleet Shower",
            "Snow Shower",
            "Heavy Snow Shower",
            "Lightning",
            "Hail",
            "Thunderstorm",
            "Heavy Thunderstorm",
            "Storm",
        ]
        weather_conditions.sort()
        oh_encoder = OneHotEncoder(categories=[weather_conditions], sparse=False)
    else:
        logger.info(
            "---Nothing has been encoded. Please, use parameters to decide what should be encoded."
        )
    return oh_encoder


"""
One Hot Encoding of the segments in the dataset. A new column is created to represent every segment. 
The encoder is passed as one parameter in order to take into account all the segments in the route, and not only the ones
in the data used as parameter.
"""


def one_hot_encode(data, encoder, segments=False, weather=False):
    if segments:
        category_cols = ["segment_id"]  # target column to be encoded
    elif weather:
        category_cols = ["condition"]

    category_cols_encoded = (
        []
    )  # it will store the names of the columns that represent each category

    encoder.categories[0]

    for col in category_cols:
        category_cols_encoded += [f"oh_{cat}" for cat in encoder.categories[0]]

    category_cols_encoded.sort()

    encoded_cols = encoder.fit_transform(data[category_cols])
    # new dataframe with only the one hot encoding attributes
    data_enc = pd.DataFrame(encoded_cols, columns=category_cols_encoded)
    data_encoded = data.join(data_enc)

    # it can happen that a test set has less categories than a train set, so get_dummies would give less
    # columns with categories provoking an error of different sizes when the train set and test set are used.
    # ->SOLUTION: define the encoder indicating all the possible categories
    return data_encoded, category_cols_encoded

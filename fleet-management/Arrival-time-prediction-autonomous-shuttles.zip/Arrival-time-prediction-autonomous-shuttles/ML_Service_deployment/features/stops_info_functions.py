import pandas as pd
import numpy as np
from geopy import distance
import calendar
from constants import STOPS_LONG

"""
This file contains the functions with the logic used to decide when a bus is in a stop or between two stops 
taking into account the GPS position in each moment. Once this information is added to the dataset, it is 
possible to generate a new datatset with the time spent by the bus in each segment of the route.
"""
#############################################################################
# ----LOGIC TO DEFINE WHEN A BUS IS IN A STOP AND NEXT AND PREVIOUS STOPS----#
#############################################################################
# ------Global variables with stops and auxiliary dictionaries-----
# The values are going to be assigned in add_stops_info()
STOPS = dict()
KI = dict()
IK = dict()

# -------------------- LOGIC FUNCTIONS TO DECIDE THE FOLLOWED ROUTE ----------------------
"""
ref_coord: reference coordinate - (lat,lon)
tested_coord: tested coordinate - (lat,lon)
treshold: threshold distance used to consider if the points are close or not

returns: boolean that indicates if the points are close or no
"""


def close_point(ref_coord, tested_coord, threshold=5):
    return distance.distance(ref_coord, tested_coord).m <= threshold


"""
Checks if the route is long (all the stops) or short (not in stops s7, s8 and s9).
Return: True for long routes
"""


def is_long_route(data):
    FAR_POINT = (58.39111, 15.58731)  # point that only appears within the long routes
    data["long_route"] = data.apply(
        lambda row: close_point((row["lat"], row["lon"]), FAR_POINT, threshold=15),
        axis=1,
    )
    is_long_route = data["long_route"].any(axis=0)
    data.drop(
        "long_route", axis=1, inplace=True
    )  # deletes the new column because it is not needed anymore
    return is_long_route


"""
Dictionary with stops and auxiliary dictionaries used to obtain in order the bus stops.
source: https://www.geeksforgeeks.org/python-get-next-key-in-dictionary/

stops: dictionary with the stops to use.
ki: index of each key in the dictionary stops
ik: key related to each index in the dictionary stops

"""


def generate_stops_order():

    stops = STOPS_LONG  # imported from constants.py

    # auxiliary dictionaries that will contain the order
    ki = dict()
    ik = dict()

    for i, k in enumerate(stops):
        ki[k] = i  # dictionary index_of_key
        ik[i] = k  # dictionary key_of_index

    return stops, ki, ik


# -------------------- LOGIC FUNCTIONS TO DECIDE IF THE BUS IS IN A STOP ----------------------
"""
stops: dictionary with the stops and its coordinates - (lat,lon)
actual_coord: actual position - (lat,lon)

return: id of the stop that the bus is approaching, or 'No stop' if there is not bus stop close
"""


def in_stop(actual_coord):
    stop = "No in stop"
    # stops = STOPS # TO DO: Adapt the dictionary of the stops depending of the bus that is being analyzed - different routes # Done
    for stop_key, stop_value in STOPS.items():
        if close_point(stop_value["coords"], actual_coord):
            # stop = value['name']
            stop = stop_key
    return stop


"""
actual_stop: actual stop that the bus is approaching or stopped at.

return: id of the next stop. To complete the dataset apply fillna(method=ffill) - forward fill to have the next stop in all the samples
"""


def next_stop(actual_stop):
    next_stop = None
    # test_key = 's10'
    offset = 1  # next stop

    if actual_stop != "No in stop":
        index_of_test_key = KI[actual_stop]
        index_of_next_key = index_of_test_key + offset
        next_stop = IK[index_of_next_key] if index_of_next_key in IK else "s0"
    return next_stop


"""
actual_stop: id of actual stop that the bus is approaching or stopped at.

return: id of the previous stop according to the dictionary
"""


def previous_stop(actual_stop):
    prev_stop = None
    offset = 1  # next stop

    if actual_stop != "No in stop":
        index_of_test_key = KI[actual_stop]
        index_of_next_key = index_of_test_key - offset
        prev_stop = IK[index_of_next_key] if index_of_next_key in IK else "s10"
    return prev_stop


#######################################################
# ----FUNCTION TO MODIFY THE DATASET WITH THE LOGIC----#
#######################################################
"""
Using the logic describe above, adds new columns to the data:
'in_stop': stop_id if the bus is close to a stop or 'No in stop' otherwise
'next_stop': stop_id of the next stop from the bus' route. It changes when the bus is close to the actual stop and continues until the next stop (fillna).
'new_round': boolean that identifies when a new round starts (change from 'in_stop'='No in stop' to 's0')
'n_round': int that shows the number of round in each moment 
"""


def add_stops_info(data, first_stop="s0", last_stop="s10"):

    # update of the global variables with the stops
    global STOPS, KI, IK
    STOPS, KI, IK = generate_stops_order()

    data["in_stop"] = data.apply(
        lambda row: in_stop((row["lat"], row["lon"])), axis=1
    )  # if bus in stop or no
    # data['name_stop'] = data.apply(lambda row : stops[row['in_stop']]['name'], axis=1) #name of the stop
    data["next_stop"] = data.apply(
        lambda row: next_stop(row["in_stop"]), axis=1
    )  # the values at the beginning of the route still None, not important since not part of segment
    data["next_stop"] = data["next_stop"].fillna(
        method="ffill"
    )  # filling empty 'next_stop' with previous 'next_stop' values

    data["prev_in_stop"] = data["in_stop"].shift(1)
    data.loc[0, "prev_in_stop"] = data.loc[0, "in_stop"]

    # writes true in the columns if in_stop changes from 'No in stop' to 's0' - start of a new round in the route
    # data['new_round']= ((data['in_stop'] == first_stop) & ((data['in_stop'].shift(1) == last_stop) | (data['in_stop'].shift(1) =='No in stop')))
    data["new_round"] = (data["in_stop"] == "s0") & (
        data["prev_in_stop"] == "No in stop"
    )

    index_changes = data.index[
        data["new_round"] == True
    ].tolist()  # indexes where new round starts
    count = np.arange(
        1, data[data["new_round"] == True]["new_round"].count() + 1, 1
    )  # creates list number of rounds

    data.loc[
        index_changes, "n_round"
    ] = count  # counter displeyed in every row where 'new_round' is True

    data["n_round"] = data["n_round"].fillna(
        method="ffill"
    )  # fills nulls with the corresponding number of round
    data = data.drop(columns=["prev_in_stop", "new_round"])

    return data


##############################################################
# ----FUNCTIONS TO GENERATE NEW DATASET WITH SEGMENTS INFO----#
##############################################################
"""
in_stop: actual position of the bus ('No in stop' or 'sX')
next_stop: next stop of the bus

return: ID of the segment in which the bus is. If the bus is in a stop, the segment_id is the stop id. 
        If the bus is between two stops, the segment_id is formed by the previous and the next stop.
"""


def get_segment_id(id_min, id_max, original_dataset):
    n_samples = len(original_dataset)

    segment_start = original_dataset.loc[
        id_min, "in_stop"
    ]  # first sample of the segment
    segment_end = original_dataset.loc[id_max, "in_stop"]  # last sample of the segment

    segment_id = None

    # segment between two stops: sX_sX
    if segment_start == "No in stop" and segment_end == "No in stop":
        segment_start = original_dataset.loc[
            (id_min - 1 if id_min != 0 else id_min), "in_stop"
        ]
        segment_end = original_dataset.loc[
            (id_max + 1 if id_max != n_samples - 1 else id_max), "in_stop"
        ]

        segment_id = segment_start + "_" + segment_end
        # TO DO: identify and remove end of the route when the bus goes to the parking area ('No in stop' -> 's0' = 's10_No in stop')

    # segment in a stop: sX
    elif segment_start != "No in stop" and segment_end != "No in stop":
        segment_id = segment_start

    # segment_id will be None if it does meet any condition - never should happen

    return segment_id


"""
day: datetime from which day will be computed
number: boolean that indicates if the result has to be the number of the day in the week or the name

return: {0:'Monday', 1:'Tuesday', 2:'Wednesday', 3:'Thursday', 4:'Friday', 5:'Saturday', 6:'Sunday'} 
"""


def day_of_week(date, number=True):
    if number:
        day = date.weekday()
    else:
        day = calendar.day_name[date.weekday()]
    return day


###############################################

# Initialization of the dictionaries
# If they are not initializaed, the functions from this file can only be used once add_stops_info(data) has been executed
STOPS, KI, IK = generate_stops_order()

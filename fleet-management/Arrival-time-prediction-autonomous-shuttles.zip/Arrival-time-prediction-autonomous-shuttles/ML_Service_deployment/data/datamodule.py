from torch.utils.data import random_split
import torch
from torch import Tensor
import pytorch_lightning as pl
import numpy as np
import yaml
from pathlib import Path
import os
import pandas as pd
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
import torch_geometric
import torch.nn.functional as F


class NoTransform:
    """Simple no transform class to make code run without transformation"""

    def __call__(
        self, his_full: Tensor, weather_full: Tensor, target_full: Tensor, train_set
    ) -> list[Tensor, Tensor, Tensor]:
        return his_full, weather_full, target_full

    def setup(self, his_train: Tensor, weather_train: Tensor, target_train: Tensor) -> None:
        self.faux_setup = True

    def transform(self, his: Tensor, weather: Tensor, target: Tensor) -> list[Tensor, Tensor, Tensor]:
        return his, weather, target

    def retransform(
        self,
        standardized_his: Tensor,
        standardized_weather: Tensor,
        standardized_target: Tensor,
    ) -> list[Tensor, Tensor, Tensor]:
        return standardized_his, standardized_weather, standardized_target

    def retransform_target_vals(self, standardized_target_vals: Tensor) -> Tensor:
        return standardized_target_vals


class Standardize:
    """Simple class for standardisation that saves params and can restandardize"""

    def setup(self, his_train: Tensor, weather_train: Tensor, target_train: Tensor) -> None:
        train_his_mean = his_train.mean((0, 1, 2))  # TODO fix which dims
        train_his_std = his_train.std((0, 1, 2))  # TODO fix which dims

        train_weather_mean = weather_train.mean((0))  # TODO fix which dims
        train_weather_std = weather_train.std((0))  # TODO fix which dims

        train_target_mean = target_train[..., 1].mean()  # TODO fix which dims
        train_target_std = target_train[..., 1].std()  # TODO fix which dims

        self.params = {
            "his": {"mean": train_his_mean, "std": train_his_std},
            "weather": {"mean": train_weather_mean, "std": train_weather_std},
            "target": {"mean": train_target_mean, "std": train_target_std},
        }

    def transform(self, his: Tensor, weather: Tensor, target: Tensor) -> list[Tensor, Tensor, Tensor]:
        standardized_his = (his - self.params["his"]["mean"]) / self.params["his"]["std"]
        standardized_weather = (weather - self.params["weather"]["mean"]) / self.params["weather"]["std"]
        standardized_target = (target[..., 1] - self.params["target"]["mean"]) / self.params["target"]["std"]
        standardized_target = torch.stack([target[..., 0], standardized_target]).T
        return standardized_his, standardized_weather, standardized_target

    def retransform(
        self,
        standardized_his: Tensor,
        standardized_weather: Tensor,
        standardized_target: Tensor,
    ) -> list[Tensor, Tensor, Tensor]:
        his = standardized_his * self.params["his"]["std"] + self.params["his"]["mean"]
        weather = standardized_weather * self.params["weather"]["std"] + self.params["weather"]["mean"]
        target = standardized_target[..., 1] * self.params["target"]["std"] + self.params["target"]["mean"]
        target = torch.stack([standardized_target[..., 0], target]).T
        return his, weather, target

    def retransform_target_vals(self, standardized_target_vals: Tensor) -> Tensor:
        assert standardized_target_vals.dim() == 1
        target_vals = standardized_target_vals * self.params["target"]["std"] + self.params["target"]["mean"]
        return target_vals


class MaxMin:
    """Simple class for standardisation that saves params and can restandardize"""

    def setup(self, his_train: Tensor, weather_train: Tensor, target_train: Tensor) -> None:
        train_his_min, _ = his_train.view(-1, 2).min(0)  # TODO fix which dims
        train_his_max, _ = his_train.view(-1, 2).max(0)  # TODO fix which dims

        train_weather_min, _ = weather_train.view(-1, 3).min(0)  # TODO fix which dims
        train_weather_max, _ = weather_train.view(-1, 3).max(0)  # TODO fix which dims

        train_target_min, _ = target_train[..., 1].min(0)  # TODO fix which dims
        train_target_max, _ = target_train[..., 1].max(0)  # TODO fix which dims

        self.params = {
            "his": {"min": train_his_min, "max": train_his_max},
            "weather": {"min": train_weather_min, "max": train_weather_max},
            "target": {"min": train_target_min, "max": train_target_max},
        }

    def transform(self, his: Tensor, weather: Tensor, target: Tensor) -> list[Tensor, Tensor, Tensor]:
        scaled_his = (his - self.params["his"]["min"]) / (self.params["his"]["max"] - self.params["his"]["min"])
        scaled_weather = (weather - self.params["weather"]["min"]) / (
            self.params["weather"]["max"] - self.params["weather"]["min"]
        )
        scaled_target = (target[..., 1] - self.params["target"]["min"]) / (
            self.params["target"]["max"] - self.params["target"]["min"]
        )

        scaled_target = torch.stack([target[..., 0], scaled_target]).T
        return scaled_his, scaled_weather, scaled_target

    def retransform(
        self,
        standardized_his: Tensor,
        standardized_weather: Tensor,
        standardized_target: Tensor,
    ) -> list[Tensor, Tensor, Tensor]:
        his = standardized_his * (self.params["his"]["max"] - self.params["his"]["min"]) + self.params["his"]["min"]
        weather = (
            standardized_weather * (self.params["weather"]["max"] - self.params["weather"]["min"])
            + self.params["weather"]["min"]
        )
        target = (
            standardized_target * (self.params["target"]["max"] - self.params["target"]["min"])
            + self.params["target"]["min"]
        )
        target = torch.stack([standardized_target[..., 0], target]).T
        return his, weather, target

    def retransform_target_vals(self, standardized_target_vals: Tensor) -> Tensor:
        assert standardized_target_vals.dim() == 1
        target_vals = (
            standardized_target_vals * (self.params["target"]["max"] - self.params["target"]["min"])
            + self.params["target"]["min"]
        )
        return target_vals


## Old dataset class - does not work currently
# class SHOWDataset(Dataset):
# """Dataset class for SHOW data that holds historical data (his), weather data and time data"""

# def __init__(
# self, his_data: Tensor, weather_data: Tensor, time_data: Tensor, target_data: Tensor, edge_index: Tensor
# ) -> None:
# self.his_data = his_data
# self.weather_data = weather_data
# self.time_data = time_data
# self.target_data = target_data
# self.edge_index = edge_index

# self.graph_data = Data(x=self.his_data, edge_index=self.edge_index)

# def __len__(self) -> int:
# return len(self.his_data)

# def __getitem__(self, idx) -> dict:
# hist_data_batch = self.his_data[idx]
# weather_data_batch = self.weather_data[idx]
# target_data_batch = self.target_data[idx]
# time_data_batch = self.time_data[idx]

# return {
# "hist_batch": hist_data_batch,
# "weather_batch": weather_data_batch,
# "time_batch": time_data_batch,
# "target": target_data_batch,
# "edge_index": self.edge_index,
# }


# TODO Typing and docstring
class SHOWDataset(Data):
    """Torch Geometric dataset extended with graph level feature"""

    def __init__(
        self,
        x: Tensor = None,
        edge_index: Tensor = None,
        edge_attr: Tensor = None,
        y: Tensor = None,
        global_feat: Tensor = None,
        node_encoding: Tensor = None,
        **kwargs,
    ) -> None:
        super().__init__(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y, **kwargs)
        self.global_feat = global_feat
        self.node_encoding = node_encoding


class SHOWDataModule(pl.LightningDataModule):
    """Lightning DataModule for SHOW data that loads historical, weather and time data.
    The data is transformed and split into train, val and test sets.
    """

    def __init__(
        self,
        site_name: str,
        transform: str,
        train_frac: float,
        num_lags: int,
        batch_size: int,
        verbose=True,
    ):
        super().__init__()
        self.site_name = site_name
        self.folder_path = (f"../../{site_name}",)

        self.batch_size = batch_size
        self.train_frac = train_frac

        self.num_lags = num_lags

        if transform == "standardize":
            self.transform = Standardize()
        elif transform == "maxmin":
            self.transform = MaxMin()
        elif transform == "none":
            self.transform = NoTransform()
        else:
            raise NotImplementedError

        self.verbose = verbose

    def setup(self, stage=None) -> Standardize:
        base_path = os.path.dirname(__file__)
        # Load predefined segment names, order and edge index
        linkoping_constants = yaml.safe_load(
            Path(f"{base_path}/processed/{self.site_name}/constants.yaml").read_text()
        )
        self.segment_lookup = {k: v for v, k in enumerate(linkoping_constants["SEGMENTS_BETWEEN_STOPS"])}
        self.edge_index = torch.Tensor(linkoping_constants["EDGE_INDEX_SEGMENTS"]).long()
        self.n_nodes = len(self.segment_lookup)

        # Load data and add node ordering
        tt_tv = pd.read_csv(f"{base_path}/processed/LINKOPING/Linkoping_travel_time_train_vehicle_1.csv")
        tt_tv["segment_idx"] = tt_tv.segment_id.map(self.segment_lookup)
        time_tv = torch.Tensor(tt_tv[["dow_sin", "dow_cos", "tod_sin", "tod_cos"]].to_numpy())
        weather_tv = torch.Tensor(tt_tv[["temp", "prcp", "wspd"]].to_numpy())
        tt_tv = torch.Tensor(tt_tv[["segment_idx", "travel_time"]].to_numpy())

        tt_test = pd.read_csv(f"{base_path}/processed/LINKOPING/Linkoping_travel_time_test_vehicle_1.csv")
        tt_test["segment_idx"] = tt_test.segment_id.map(self.segment_lookup)
        time_test = torch.Tensor(tt_test[["dow_sin", "dow_cos", "tod_sin", "tod_cos"]].to_numpy())
        weather_test = torch.Tensor(tt_test[["temp", "prcp", "wspd"]].to_numpy())
        tt_test = torch.Tensor(tt_test[["segment_idx", "travel_time"]].to_numpy())

        his_data = np.load(
            f"{base_path}/processed/LINKOPING/Linkoping_lags_tt_train_vehicle_1.npy",
            allow_pickle=True,
        )
        his_data = np.stack(his_data)
        his_segment_order = his_data[100, :, 0, 0]
        his_data = torch.Tensor(his_data[..., -self.num_lags :, 1:].astype("float64"))

        his_test = np.load(
            f"{base_path}/processed/LINKOPING/Linkoping_lags_tt_test_vehicle_1.npy",
            allow_pickle=True,
        )
        his_test = np.stack(his_test)
        his_test_segment_order = his_test[100, :, 0, 0]
        his_test = torch.Tensor(his_test[..., -self.num_lags :, 1:].astype("float64"))

        # Node ordering sanity check
        for i in range(len(self.segment_lookup)):
            assert his_test_segment_order[i] == his_segment_order[i]
            assert self.segment_lookup[his_segment_order[i]] == i

        # Create val and train split
        tv_obs_full = len(his_data)
        val_len = int(tv_obs_full * (1 - self.train_frac))
        train_len = tv_obs_full - val_len
        # Frozen seed for reproducibility
        train_set, val_set = random_split(
            range(tv_obs_full),
            [train_len, val_len],
            generator=torch.Generator().manual_seed(1),
        )

        his_train = his_data[train_set.indices]
        his_val = his_data[val_set.indices]

        time_train = time_tv[train_set.indices]
        time_val = time_tv[val_set.indices]

        weather_train = weather_tv[train_set.indices]
        weather_val = weather_tv[val_set.indices]

        tt_train = tt_tv[train_set.indices]
        tt_val = tt_tv[val_set.indices]

        # Transform the data w. the given tranformation
        self.transform.setup(his_train=his_train, weather_train=weather_train, target_train=tt_train)
        tfed_his_train, tfed_weather_train, tfed_tt_train = self.transform.transform(
            his=his_train, weather=weather_train, target=tt_train
        )
        tfed_his_val, tfed_weather_val, tfed_tt_val = self.transform.transform(
            his=his_val, weather=weather_val, target=tt_val
        )
        tfed_his_test, tfed_weather_test, tfed_tt_test = self.transform.transform(
            his=his_test, weather=weather_test, target=tt_test
        )

        # Create graph level feature
        global_train = torch.cat([time_train, tfed_weather_train], dim=1)
        global_val = torch.cat([time_val, tfed_weather_val], dim=1)
        global_test = torch.cat([time_test, tfed_weather_test], dim=1)

        node_one_hot_encoding = F.one_hot(torch.tensor(list(range(self.n_nodes))))

        # Create datasets that can be used w. torch geometric
        self.train_data = [
            SHOWDataset(
                x=x,
                edge_index=self.edge_index,
                y=y,
                global_feat=global_feat,
                node_encoding=node_one_hot_encoding,
            )
            for x, y, global_feat in zip(tfed_his_train, tfed_tt_train, global_train)
        ]

        self.val_data = [
            SHOWDataset(
                x=x,
                edge_index=self.edge_index,
                y=y,
                global_feat=global_feat,
                node_encoding=node_one_hot_encoding,
            )
            for x, y, global_feat in zip(tfed_his_val, tfed_tt_val, global_val)
        ]

        self.test_data = [
            SHOWDataset(
                x=x,
                edge_index=self.edge_index,
                y=y,
                global_feat=global_feat,
                node_encoding=node_one_hot_encoding,
            )
            for x, y, global_feat in zip(tfed_his_test, tfed_tt_test, global_test)
        ]
        return self.transform

    def train_dataloader(self) -> type[DataLoader]:
        return DataLoader(self.train_data, batch_size=self.batch_size, shuffle=True, num_workers=1)

    def val_dataloader(self) -> type[DataLoader]:
        return DataLoader(self.val_data, batch_size=self.batch_size, shuffle=False, num_workers=1)

    def test_dataloader(self) -> type[DataLoader]:
        return DataLoader(self.test_data, batch_size=self.batch_size, shuffle=False, num_workers=1)

import pandas as pd
from geopy import distance
import dateutil.parser
import calendar
import numpy as np
import hydra
import dateutil
from meteostat import Hourly
from datetime import timedelta
from omegaconf import DictConfig, OmegaConf
import hydra


def close_point(ref_coord, tested_coord, threshold=5):
    return distance.distance(ref_coord, tested_coord).m <= threshold


def in_stop(actual_coord):
    stop = "No in stop"
    # stops = STOPS # TO DO: Adapt the dictionary of the stops depending of the bus that is being analyzed - different routes # Done
    for stop_key, stop_value in STOPS.items():
        if close_point(stop_value["coords"], actual_coord):
            # stop = value['name']
            stop = stop_key
    return stop


"""
actual_stop: actual stop that the bus is approaching or stopped at.

return: id of the next stop. To complete the dataset apply fillna(method=ffill) - forward fill to have the next stop in all the samples
"""


def next_stop(actual_stop):
    next_stop = None
    # test_key = 's10'
    offset = 1  # next stop

    if actual_stop != "No in stop":
        index_of_test_key = KI[actual_stop]
        index_of_next_key = index_of_test_key + offset
        next_stop = IK[index_of_next_key] if index_of_next_key in IK else "s0"
    return next_stop


def generate_stops_order(constants):
    stops = constants.STOPS_LONG  # imported from constants.py
    # auxiliary dictionaries that will contain the order
    ki = dict()
    ik = dict()
    for i, k in enumerate(stops):
        ki[k] = i  # dictionary index_of_key
        ik[i] = k  # dictionary key_of_index
    return stops, ki, ik


def add_stops_info(data, constants, first_stop="s0", last_stop="s10"):
    # update of the global variables with the stops
    global STOPS, KI, IK
    STOPS, KI, IK = generate_stops_order(constants)

    data["in_stop"] = data.apply(
        lambda row: in_stop((row["lat"], row["lon"])), axis=1
    )  # if bus in stop or no
    # data['name_stop'] = data.apply(lambda row : stops[row['in_stop']]['name'], axis=1) #name of the stop
    data["next_stop"] = data.apply(
        lambda row: next_stop(row["in_stop"]), axis=1
    )  # the values at the beginning of the route still None, not important since not part of segment
    data["next_stop"] = data["next_stop"].fillna(
        method="ffill"
    )  # filling empty 'next_stop' with previous 'next_stop' values

    data["prev_in_stop"] = data["in_stop"].shift(1)
    data.loc[0, "prev_in_stop"] = data.loc[0, "in_stop"]

    # writes true in the columns if in_stop changes from 'No in stop' to 's0' - start of a new round in the route
    # data['new_round']= ((data['in_stop'] == first_stop) & ((data['in_stop'].shift(1) == last_stop) | (data['in_stop'].shift(1) =='No in stop')))
    data["new_round"] = (data["in_stop"] == "s0") & (
        data["prev_in_stop"] == "No in stop"
    )

    index_changes = data.index[
        data["new_round"] == True
    ].tolist()  # indexes where new round starts
    count = np.arange(
        1, data[data["new_round"] == True]["new_round"].count() + 1, 1
    )  # creates list number of rounds

    data.loc[
        index_changes, "n_round"
    ] = count  # counter displeyed in every row where 'new_round' is True

    data["n_round"] = data["n_round"].fillna(
        method="ffill"
    )  # fills nulls with the corresponding number of round
    data = data.drop(columns=["prev_in_stop", "new_round"])

    return data


def transform_data(data, speeds=True):
    data["last_seen"] = data.apply(
        lambda row: dateutil.parser.parse(row["last_seen"]), axis=1
    )
    # data['last_seen'] =   data.apply(lambda row : datetime.datetime.strptime(row['last_seen'], '%Y-%m-%dT%H:%M:%S.%fZ'), axis = 1)
    return data


def get_segment_id(id_min, id_max, original_dataset):
    n_samples = len(original_dataset)

    segment_start = original_dataset.loc[
        id_min, "in_stop"
    ]  # first sample of the segment
    segment_end = original_dataset.loc[id_max, "in_stop"]  # last sample of the segment

    segment_id = None

    # segment between two stops: sX_sX
    if segment_start == "No in stop" and segment_end == "No in stop":
        segment_start = original_dataset.loc[
            (id_min - 1 if id_min != 0 else id_min), "in_stop"
        ]
        segment_end = original_dataset.loc[
            (id_max + 1 if id_max != n_samples - 1 else id_max), "in_stop"
        ]

        segment_id = segment_start + "_" + segment_end
        # TO DO: identify and remove end of the route when the bus goes to the parking area ('No in stop' -> 's0' = 's10_No in stop')

    # segment in a stop: sX
    elif segment_start != "No in stop" and segment_end != "No in stop":
        segment_id = segment_start

    # segment_id will be None if it does meet any condition - never should happen

    return segment_id


def day_of_week(date, number=True):
    if number:
        day = date.weekday()
    else:
        day = calendar.day_name[date.weekday()]
    return day


def segment_is_correct(segment):
    stops_in_segment = segment.split("_")
    correct = True

    # print(stops_in_segment)

    # if there is a string that is not a stop id is not correct, e.g. s10_No in stop
    if not all(stop in STOPS for stop in stops_in_segment):
        correct = False
        # print('Wrong stop id')

    # if segment between two stops, check that consecutive stops
    if len(stops_in_segment) > 1:
        expected_next_stop = next_stop(stops_in_segment[0])
        correct = expected_next_stop == stops_in_segment[1]

        # special cases when shortest route is allowed
        if (stops_in_segment[0] == "s6") & (stops_in_segment[1] == "s10"):
            correct = True

        # print('Not consecutive') if not correct else print('Consecutive')
    return correct


def check_segments(segments_data, logger):
    n_samples_original = len(segments_data)
    segments_data["correct_segment"] = segments_data.apply(
        lambda row: segment_is_correct(row["segment_id"]), axis=1
    )
    segments_data = segments_data[segments_data["correct_segment"] == True]
    segments_data = segments_data.drop(columns=["correct_segment"])
    n_samples_later = len(segments_data)
    logger.info(
        "---Deleted {} invalid segments".format(n_samples_original - n_samples_later)
    )
    return segments_data


def generate_dataset_from_data(data):
    # groups by 'in_stop', 'next_stop', 'n_round' keeping the first and last value of time in the segment (start_time and end_time) and their index in the original dataset
    segments = (
        data.groupby(["in_stop", "next_stop", "n_round"])
        .last_seen.agg(
            [
                "min",
                ("id_min", lambda x: x.idxmin()),
                "max",
                ("id_max", lambda x: x[::-1].idxmax()),
            ]
        )
        .rename(columns={"min": "start_time", "max": "end_time"})
    )

    columns = ["date", "segment_id", "travel_time"]
    segments_data = []
    segments["end_time"] = segments.apply(
        lambda row: row["end_time"].replace(tzinfo=None, microsecond=0), axis=1
    )
    segments["start_time"] = segments.apply(
        lambda row: row["start_time"].replace(tzinfo=None, microsecond=0), axis=1
    )
    # loops over rows in group by
    lag_s = 0
    lag_time = 0
    s_id = 0
    hist_data = {}
    history = [0] * len(STOPS.keys())
    for start, end, n_round in segments.index.tolist():
        row = segments.loc[start].loc[end].loc[n_round]
        date = row["start_time"]
        segment_id = get_segment_id(row["id_min"], row["id_max"], data)
        # if s_id != segment_id:
        #    lag_s = 0
        #    lag_time = 0
        #    s_id = segment_id
        travel_time = (row["end_time"] - row["start_time"]).total_seconds()
        # if lag_time != 0:
        #    delta = (row["start_time"] - lag_time).seconds
        # else:
        #    delta = 0
        segments_data.append([date, segment_id, travel_time])

        lag_time = row["start_time"]
        lag_s = travel_time

    segments_dataset = pd.DataFrame(data=segments_data, columns=columns)

    if len(segments_dataset) > 0:
        segments_dataset["dow"] = segments_dataset.apply(
            lambda row: day_of_week(row["date"]), axis=1
        )
        segments_dataset["dow_day"] = segments_dataset.apply(
            lambda row: day_of_week(row["date"], False), axis=1
        )
        segments_dataset["date"] = segments_dataset.apply(
            lambda row: row["date"].replace(tzinfo=None, microsecond=0), axis=1
        )
        segments_dataset["tod"] = (
            (
                segments_dataset["date"]
                - pd.TimedeltaIndex(segments_dataset["date"].dt.minute % 15, "m")
            )
            - pd.TimedeltaIndex(segments_dataset["date"].dt.second, "s")
        ).dt.time

    return segments_dataset


def encode_dow(data):
    data["dow"] = (
        data["dow"] + 1
    )  # necessary? why not change mapping days in day_of_week()?
    # max_dow = data['dow'].max()
    max_dow = 7  # it must be the maximum possible value, not the maximum registered

    data["dow_sin"] = np.sin(2 * np.pi * data["dow"] / max_dow)
    data["dow_cos"] = np.cos(2 * np.pi * data["dow"] / max_dow)
    return data


"""
Auxiliar function that creates a list of datetimes from start (datetime) to end (datetime) 
with intervals defined by delta
"""


def datetime_range(start, end, delta):
    current = start
    while current < end:
        yield current
        current += delta


"""
Encodes time of the day using sine and cosine, being able like this to keep its the cyclic nature 
"""


def encode_tod(data, constants):
    # maps tod with the encoding value
    data["tod_encoded"] = data.apply(
        lambda row: constants.DICT_TIME_ENCODING[str(row["tod"])], axis=1
    )

    # cyclic encoding with sine and cosine
    max_tod = constants.DICT_TIME_ENCODING[
        "23:45:00"
    ]  # it must be the maximum possible value (23:45:00, not the maximum registered value)
    data["tod_sin"] = np.round(
        np.sin(2 * np.pi * data["tod_encoded"] / max_tod), decimals=6
    )
    data["tod_cos"] = np.round(
        np.cos(2 * np.pi * data["tod_encoded"] / max_tod), decimals=6
    )

    # data.drop(labels=['tod_encoded'])
    return data


"""
One Hot Encoding of the segments in the dataset. A new column is created to represent every segment. 
The encoder is passed as one parameter in order to take into account all the segments in the route, and not only the ones
in the data used as parameter.
"""


def one_hot_encode(data, encoder, segments=False, weather=False):
    if segments:
        category_cols = ["segment_id"]  # target column to be encoded
    elif weather:
        category_cols = ["condition"]

    category_cols_encoded = (
        []
    )  # it will store the names of the columns that represent each category

    encoder.categories[0]

    for col in category_cols:
        category_cols_encoded += [f"oh_{cat}" for cat in encoder.categories[0]]

    category_cols_encoded.sort()

    encoded_cols = encoder.fit_transform(data[category_cols])
    # new dataframe with only the one hot encoding attributes
    data_enc = pd.DataFrame(encoded_cols, columns=category_cols_encoded)
    data_encoded = data.join(data_enc)

    # it can happen that a test set has less categories than a train set, so get_dummies would give less
    # columns with categories provoking an error of different sizes when the train set and test set are used.
    # ->SOLUTION: define the encoder indicating all the possible categories
    return data_encoded, category_cols_encoded


def add_weather(data):
    data["date_1h"] = data.apply(
        lambda row: row["date"].replace(minute=0, second=0, microsecond=0), axis=1
    )  # identifying 1 hour intervals in the data
    start = data.date.min() - timedelta(days=1)
    end = data.date.max() + timedelta(days=1)
    weather_data = (
        Hourly("02562", start, end).fetch().reset_index()
    )  # gets a dataset with weather info (1 hour intervals) at station number 02562 - Linköping
    weather_data = weather_data[["time", "temp", "prcp", "snow", "wspd"]]
    weather_data = weather_data.fillna(0)
    # weather_data['condition'] = weather_data.apply(lambda row : condition_code[row['coco']], axis=1)

    data_with_weather = pd.merge(
        data, weather_data, how="left", left_on="date_1h", right_on="time"
    )  # left join adds weather to dataset. Join on 'date_1h' and 'time'
    data_with_weather = data_with_weather.drop(columns=["date_1h", "time"])
    return data_with_weather


"""
Computes statistical values needed for the IQR of each segment.
"""


def segments_info(data):
    if "travel_time" in data.columns:
        attribute = "travel_time"
    else:
        attribute = "y_test"

    cut_off_factor = 1.5
    segments_info = data.groupby("segment_id")[attribute].agg(
        [
            "mean",
            "min",
            "max",
            "std",
            ("q25", lambda x: np.percentile(x, 25)),
            ("q50", lambda x: np.percentile(x, 50)),
            ("q75", lambda x: np.percentile(x, 75)),
            ("q95", lambda x: np.percentile(x, 95)),
        ]
    )
    # compute interquantile ranges
    segments_info["iqr"] = segments_info["q75"] - segments_info["q25"]
    # compute outliers cut offs
    segments_info["lower"] = np.maximum(
        segments_info["q25"] - (cut_off_factor * segments_info["iqr"]),
        segments_info["min"],
    )
    segments_info["upper"] = np.minimum(
        segments_info["q75"] + (cut_off_factor * segments_info["iqr"]),
        segments_info["max"],
    )
    return segments_info


"""
Identifies and removes all the outliers from the dataset. The following cases are considered outliers:
- Samples with negative travel time or 0, since the travel time of a bus in a segment cannot be 0 or lower.
- Samples in s10_s0 contain moments in which the bus has stopped in the parking in order to recharge the batteries. These data cannot be considered
  by the model, since it is not a realistic representation of the travel time in the segment
- Samples above the upper limit using IQR (Interquantile Range Method). Samples below the lower limit are not considered outliers, since they 
  correspond to moments in which the bus has passed close to the stop but without stopping on it
"""


def remove_outliers(data):
    print("Initial number of samples: {}".format(data["travel_time"].count()))

    ######## 1) Removing outliers manually ###########################

    # samples with travel time 0 are also outliers (wrong bus' stop position?), since the travel time of a bus in segment can not be 0
    # data['outlier_0'] = data.apply(lambda row : row['travel_time'] == 0, axis=1)
    ##THIS SAMPLES SHOULD BE TRANSFORMED TO TRAVEL_TIME 1 BECAUSE MAYBE THEY MOSTLY CORRESPOND TO SITUATIONS IN WHICH THE BUS DOESNT STOP!!
    print(
        "Transforming {} samples with travel_time 0.".format(
            data[(data["travel_time"] == 0) & (data["segment_id"] != "s0")][
                "travel_time"
            ].count()
        )
    )
    data.loc[
        (data["travel_time"] == 0) & (data["segment_id"] != "s0"), "travel_time"
    ] = 1

    data["outlier_s0_0"] = data[(data["segment_id"] == "s0")].apply(
        lambda row: row["travel_time"] == 0, axis=1
    )

    # outliers in segment s10_s0 should be removed manually, since there is not any pattern to detect them.
    # They correspond to the samples in which the bus stops in the parking in between the stop s10 and s0, so it does not correspond to the real travel time.
    # all travel times above 650 s in the segment s10_s0 will be considered outliers
    data["outlier_s10_s0"] = data[(data["segment_id"] == "s10_s0")].apply(
        lambda row: row["travel_time"] > 650, axis=1
    )

    print(
        "Removing {} outliers with travel_time 0 in segment s0.".format(
            data[(data["travel_time"] == 0) & (data["segment_id"] == "s0")][
                "travel_time"
            ].count()
        )
    )
    print(
        "Removing {} outliers corresponding to parking times in s10_s0 segment.".format(
            data[(data["outlier_s10_s0"] == True)]["travel_time"].count()
        )
    )

    data = data[
        (data["outlier_s10_s0"] != True) & (data["outlier_s0_0"] != True)
    ]  # oulier_s10_s0 can be True, False or None, we want to remove Trues

    ######## 2) Removing outliers automatically - IQR method #########

    # IMPORTANT! This step must be made after removing manually the outliers since the iqr, lower and upper values change
    # after removing some samples manually -> recompute iqr_stats
    iqr_stats = segments_info(data)

    # considering outliers the samples with travel_time above upper - the ones under the lower limit are not outliers since they can correspond to real data in which a bus doesnt stops
    data = data.assign(
        outlier_iqr=data.apply(
            lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper,
            axis=1,
        )
    )
    # data["outlier_iqr"] = data.apply(lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper, axis=1)

    print(
        "Removing {} outliers detected by IQR method.".format(
            data[(data["outlier_iqr"] == True)]["travel_time"].count()
        )
    )
    data = data[data["outlier_iqr"] == False]

    data = data.drop(columns=["outlier_iqr", "outlier_s10_s0", "outlier_s0_0"])
    data = data.reset_index(drop=True)

    print(
        "After removing outliers, the dataset set is formed by {} samples.".format(
            data["travel_time"].count()
        )
    )
    return data


def get_hist_data(
    obs, data, constants, TT=True, horizon=4
):  # data already sorted by time
    date = obs["date"]
    data_filtered = data[data["date"] < date]
    data_filtered = data_filtered.groupby("segment_id")
    data_filtered = data_filtered.tail(horizon)
    data_filtered["delta"] = data_filtered["date"].apply(
        lambda row: (date - row).total_seconds()
    )
    if TT:
        data_filtered = data_filtered[["segment_id", "travel_time", "delta"]]
        l = [
            data_filtered[data_filtered["segment_id"] == s].to_numpy()
            for s in constants.SEGMENTS_BETWEEN_STOPS
        ]
    else:
        data_filtered = data_filtered[["segment_id", "dwell_time", "delta"]]
        l = [
            data_filtered[data_filtered["segment_id"] == s].to_numpy()
            for s in constants.STOPS
        ]
    for i in range(len(l)):  # zero pad
        if l[i].shape != (4, 3):
            l[i] = np.vstack([l[i], np.zeros([4 - l[i].shape[0], 3])])
    return np.stack(l)

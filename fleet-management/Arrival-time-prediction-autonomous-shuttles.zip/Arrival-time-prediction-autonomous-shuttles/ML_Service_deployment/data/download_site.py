import pandas as pd
import click

from api_utils import query_full_api, API_DICT, assert_consistent_meta


@click.command()
@click.option(
    "--city",
    type=click.Choice(["MADRID", "GRAZ", "BRNO", "LINKOPING", "TAMPERE"]),
    required=True,
)
@click.option("--feature", type=str, required=False)
@click.option("--vehicle", type=str, required=False)
def download_site(city: str, feature: str = None, vehicle: str = None) -> None:
    """Downloads data from the SHOW data API and saves it as a csv in the raw data folder

    Args:
        city (str): Name of the site to download. Has to be one of ["MADRID", "GRAZ", "BRNO", "LINKOPING", "TAMPERE"]
        feature (str, optional): If given only download the given feature. Has to an available feature at the site.
         Defaults to None in which case it downloads all features.
    """
    city_dict = API_DICT[city]

    if feature is None:
        features = city_dict.keys()
    else:
        features = [feature]

    for feature in features:
        feature_dict = city_dict[feature]

        if vehicle is None:
            vehicles = feature_dict.keys()
        else:
            vehicles = [vehicle]

        for vehicle in vehicles:
            url = feature_dict[vehicle]
            print(f"Downloading {city}-{feature}-{vehicle}")
            data_list, meta_list = query_full_api(url=url)
            data_df = pd.concat(data_list).reset_index(drop=True)
            assert_consistent_meta(meta_list)
            data_df.to_csv(f"../../data/raw/{city}/{city}_{vehicle}_{feature}.csv")


if __name__ == "__main__":
    download_site()

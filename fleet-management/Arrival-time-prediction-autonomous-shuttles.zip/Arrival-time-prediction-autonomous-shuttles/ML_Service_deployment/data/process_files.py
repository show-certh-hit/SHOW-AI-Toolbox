import pandas as pd
import glob
import logging
from preprocess_utils import *


def set_up_logger():
    # create logger
    logger = logging.getLogger(__name__)
    # set log level for all handlers to info
    logger.setLevel(logging.INFO)

    # create console handler and set level to debug
    # best for development or debugging
    consoleHandler = (
        logging.StreamHandler()
    )  # create only one handler to dont have repeated messages
    consoleHandler.setLevel(logging.INFO)

    # # create formatter
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    # # add formatter to ch
    consoleHandler.setFormatter(formatter)

    # # add ch to logger
    logger.addHandler(consoleHandler)
    print("Logger is ready")
    return logger


def load_and_process_file(path, constants):
    df = pd.read_csv(path, delimiter=",", header=0)
    logger.info(f"-Loaded dataset of size:{len(df)}")

    df["lat"] = df["position"].apply(lambda x: eval(x)["geoPosition"]["latitude"])
    df["lon"] = df["position"].apply(lambda x: eval(x)["geoPosition"]["longitude"])
    df = df.rename(columns={"timestamp": "last_seen"})

    logger.info("--Transforming data")
    df = transform_data(df, speeds=False)
    logger.info("--Adding stops info")
    df = add_stops_info(df, constants=constants)
    logger.info("--Generating segments dataset")
    segments_data = generate_dataset_from_data(df)
    logger.info("--Checking valid segments")
    segments_data = check_segments(segments_data, logger)
    logger.info("--File processed successfully")
    return segments_data


def process_all_files(
    path="/Data/linkoping-vehicle-", file_name_out="SegmentsDataset", constants=None
):
    logger.info("-Loading files from path: {}".format(path))
    files = glob.glob(path)

    segments_dataset = pd.DataFrame()
    content = []

    for file in files:
        data_from_file = load_and_process_file(path=file, constants=constants)
        content.append(data_from_file)

    logger.info("-Merging data in one dataset")
    segments_dataset = pd.concat(content, ignore_index=True)

    logger.info("-Saving dataset in file")
    segments_dataset.to_csv(
        "/home/csasc/SHOW_ML_Service/data/interim/{}.csv".format(file_name_out),
        index=False,
    )
    logger.info("-CSV saved as {}.csv".format(file_name_out))
    return segments_dataset


if __name__ == "__main__":
    constants = OmegaConf.load("./conf/constants.yaml")
    logger = set_up_logger()
    preprocess = False
    if preprocess:
        data = process_all_files(
            path=f"/home/csasc/SHOW_ML_Service/data/raw/LINKOPING/LINKOPING_linkoping-vehicle-{constants.VEHICLE}_LOCATION.csv",
            file_name_out=f"SegmentsDataset_vehicle{constants.VEHICLE}",
            constants=constants,
        )

        data = remove_outliers(data)

        data = add_weather(data)

        data = encode_dow(data)

        data = encode_tod(data=data, constants=constants)

        segment_travel = data[data["segment_id"].str.contains("_")]
        segment_dwell = data[~data["segment_id"].str.contains("_")]

        segment_travel = segment_travel[
            [
                "segment_id",
                "travel_time",
                "temp",
                "prcp",
                "snow",
                "wspd",
                "dow_sin",
                "dow_cos",
                "tod_sin",
                "tod_cos",
                "date",
            ]
        ]
        segment_dwell = segment_dwell[
            [
                "segment_id",
                "travel_time",
                "temp",
                "prcp",
                "snow",
                "wspd",
                "dow_sin",
                "dow_cos",
                "tod_sin",
                "tod_cos",
                "date",
            ]
        ].rename(columns={"travel_time": "dwell_time"})
        segment_travel = segment_travel.sort_values("date")
        segment_dwell = segment_dwell.sort_values("date")

        segment_travel.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/interim/Linkoping_travel_time_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )
        segment_dwell.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/interim/Linkoping_dwell_time_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )
    else:
        path = f"/home/csasc/SHOW_ML_Service/data/interim/Linkoping_travel_time_vehicle_{constants.VEHICLE}.csv"
        segment_travel = pd.read_csv(path, delimiter=",", header=0)
        segment_travel["date"] = segment_travel.apply(
            lambda row: dateutil.parser.parse(row["date"]), axis=1
        )
        segment_travel = segment_travel.sort_values("date")

        path = f"/home/csasc/SHOW_ML_Service/data/interim/Linkoping_dwell_time_vehicle_{constants.VEHICLE}.csv"
        segment_dwell = pd.read_csv(path, delimiter=",", header=0)
        segment_dwell["date"] = segment_dwell.apply(
            lambda row: dateutil.parser.parse(row["date"]), axis=1
        )
        segment_dwell = segment_dwell.sort_values("date")

        segment_travel_test = segment_travel[
            segment_travel["date"].dt.strftime("%Y-%m") == "2022-03"
        ]
        segment_travel_test = segment_travel_test.sort_values("date")
        segment_travel_train = segment_travel[
            segment_travel["date"].dt.strftime("%Y-%m") != "2022-03"
        ]
        segment_travel_train = segment_travel_train.sort_values("date")

        logger.info(
            f"-Created travel time prediction data set {len(segment_travel)}. Training set size {len(segment_travel_train)}, Test set size {len(segment_travel_test)}"
        )
        segment_travel_test.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_travel_time_test_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )
        segment_travel_train.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_travel_time_train_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )

        lags_tt_train = segment_travel_train.apply(
            get_hist_data, args=(segment_travel_train, constants, True, 4), axis=1
        )
        lags_tt_test = segment_travel_test.apply(
            get_hist_data, args=(segment_travel_test, constants, True, 4), axis=1
        )

        with open(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_lags_tt_train_vehicle_{constants.VEHICLE}.npy",
            "wb",
        ) as f:
            np.save(f, lags_tt_train, allow_pickle=True)

        with open(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_lags_tt_test_vehicle_{constants.VEHICLE}.npy",
            "wb",
        ) as f:
            np.save(f, lags_tt_test, allow_pickle=True)

        logger.info(f"-Created lags for travel time prediction")

        segment_dwell_test = segment_dwell[
            segment_dwell["date"].dt.strftime("%Y-%m") == "2022-03"
        ]
        segment_dwell_test = segment_dwell_test.sort_values("date")
        segment_dwell_train = segment_dwell[
            segment_dwell["date"].dt.strftime("%Y-%m") != "2022-03"
        ]
        segment_dwell_train = segment_dwell_train.sort_values("date")

        logger.info(
            f"-Created travel dwell prediction data set {len(segment_dwell)}. Training set size {len(segment_dwell_train)}, Test set size {len(segment_dwell_test)}"
        )
        segment_dwell_train.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_dwell_time_train_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )
        segment_dwell_test.to_csv(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_dwell_time_test_vehicle_{constants.VEHICLE}.csv",
            index=False,
        )

        lags_dt_train = segment_dwell_train.apply(
            get_hist_data, args=(segment_dwell_train, constants, False, 4), axis=1
        )
        lags_dt_test = segment_dwell_test.apply(
            get_hist_data, args=(segment_dwell_test, constants, False, 4), axis=1
        )

        with open(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_lags_dt_train_vehicle_{constants.VEHICLE}.npy",
            "wb",
        ) as f:
            np.save(f, lags_dt_train, allow_pickle=True)

        with open(
            f"/home/csasc/SHOW_ML_Service/data/processed/Linkoping_lags_dt_test_vehicle_{constants.VEHICLE}.npy",
            "wb",
        ) as f:
            np.save(f, lags_dt_test, allow_pickle=True)

        logger.info(f"-Created lags for dwell time prediction")

import requests
import pandas as pd
import yaml
from pathlib import Path
import time
import click
from tqdm import tqdm


TOKEN_URL = "https://show-data-portal.eu:2053/auth/realms/show_kpis/protocol/openid-connect/token"

api_info = yaml.safe_load(
    Path(
        "/home/manity/SHOW_folder/SHOW_ML_Service/src/data/token_secret.yaml"
    ).read_text()
)
TOKEN_HEADERS = api_info["TOKEN_HEADERS"]
TOKEN_DATA = api_info["TOKEN_DATA"]
API_DICT = api_info["API_DICT"]


class ObjectId:
    def __init__(self, _id):
        self._id = _id


def get_auth_token():
    """Gets the authentication token based on the user information placed in TOKEN_DATA in the 'token_secret' file.

    Returns:
        string: string with the access token.
    """
    token_response = requests.post(TOKEN_URL, data=TOKEN_DATA).json()
    return token_response["access_token"]


def query_api(url, token, page):
    head = {"Authorization": f"Bearer {token}"}
    data_request = requests.get(f"{url}?page={page}", headers=head)
    data_request_json = data_request.json()
    return data_request_json


def handle_response(request_json, meta_data_dict_list, data_list):
    meta_data_dict_list.append(
        {
            "Timestamp": request_json["Timestamp"],
            "Entity": request_json["Entity"],
            "Entityid": request_json["Entityid"],
            "has_next": request_json["has_next"],
            "number_of_entries": request_json["number_of_entries"],
        }
    )

    loaded_data = eval(request_json["data"])
    df = pd.DataFrame(loaded_data)
    df["Id"] = df._id.map(lambda elem: elem._id)
    data_list.append(df)

    data_left = request_json["has_next"] == "True"
    return meta_data_dict_list, data_list, data_left


def query_full_api(url, first_page=0):

    # Get initial token
    token = get_auth_token()
    token_time = time.time()

    data_left = True
    meta_data_dict_list = []
    data_list = []

    # Get initial data and get size of full data
    request_json = query_api(url=url, token=token, page=first_page)
    meta_data_dict_list, data_left, data_left = handle_response(
        request_json, meta_data_dict_list, data_list
    )

    total_pages = int(int(request_json["number_of_entries"]) / 1000)

    # Get rest of data
    for page in tqdm(range(first_page + 1, total_pages)):
        if (time.time() - token_time) > 250:
            # Update token
            token = get_auth_token()
            token_time = time.time()

        # Retry 10 times if request fails
        for attempts in range(10):
            try:
                request_json = query_api(url=url, token=token, page=page)
            except:
                token = get_auth_token()
                time.sleep(10)
            else:
                break

        meta_data_dict_list, data_left, data_left = handle_response(
            request_json, meta_data_dict_list, data_list
        )

        if page == total_pages:
            assert not data_left

        # Sleep to not overload API
        time.sleep(2)

    return data_list, meta_data_dict_list


def query_subset_api(url, last_page):
    # Get initial token
    token = get_auth_token()
    token_time = time.time()

    data_left = True
    meta_data_dict_list = []
    data_list = []
    for page in range(last_page):
        if (time.time() - token_time) > 250:
            # Update token
            token = get_auth_token()
            token_time = time.time()

        request_json = query_api(url=url, token=token, page=page)

        meta_data_dict_list.append(
            {
                "Timestamp": request_json["Timestamp"],
                "Entity": request_json["Entity"],
                "Entityid": request_json["Entityid"],
                "has_next": request_json["has_next"],
                "number_of_entries": request_json["number_of_entries"],
            }
        )

        loaded_data = eval(request_json["data"])
        df = pd.DataFrame(loaded_data)
        df["Id"] = df._id.map(lambda elem: elem._id)
        data_list.append(df)

        data_left = request_json["has_next"] == "True"
        print(f"Requesting page {page}, has next is {data_left}", end="\r")
        page += 1

        # Sleep to not overload API
        time.sleep(1)

    return data_list, meta_data_dict_list


def assert_consistent_meta(meta_list):
    init_meta = meta_list[0]

    for meta in meta_list[1:]:
        assert meta["Entity"] == init_meta["Entity"]
        assert meta["Entityid"] == init_meta["Entityid"]

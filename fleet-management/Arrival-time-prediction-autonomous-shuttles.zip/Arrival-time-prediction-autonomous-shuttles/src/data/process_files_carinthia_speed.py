from datetime import timedelta
import dateutil
import dateutil.parser
import numpy as np
import pandas as pd
from geopy import distance
from meteostat import Hourly
from omegaconf import OmegaConf
import argparse
#[47.03041,15.42795], [47.03021,15.42812],[47.03022, 15.42885], [47.03043,15.42862]]

def close_point(ref_coord, tested_coord, threshold=15):
    return distance.distance(ref_coord, tested_coord).m <= threshold


def in_stop(actual_coord):
    '''Returns the stop id if the bus is in a stop, else returns "No"'''
    stop = "No"

    global C_STOP

    for s in NEXT_STOPS[C_STOP]:
        #if s ==0:
        #    if close_point(NEW_STOPS[s]["coords"], actual_coord, threshold = 35):
        #        C_STOP = s
        #        stop = s
        #        break
        if close_point(NEW_STOPS[s]["coords"], actual_coord):
            C_STOP = s
            stop = s
            break
    return stop


def add_stops_info(data, stops, next_stops):
    '''Adds the stop_id column to the data and deletes rows that are not in a stop'''
    global NEW_STOPS, C_STOP, NEXT_STOPS
    C_STOP = 12
    data["stop_id"] = data.apply(lambda row: in_stop((row["lat"], row["lon"])), axis=1)  

    data = data[data.stop_id != 'No']
    data["standing"] = data.apply(lambda row: row['speed']<0.01, axis=1)  

    return data

def create_segment_ids(stop, prev_stop):
    if stop != prev_stop:
        return f"{stop}_{prev_stop}"
    else:
        return stop
    

def calculate_dwell_start(group):
    if group['standing'].any(): # Checks if any row in the group has 'standing' == True
        standing_group = group[group['standing'] == True]
        start_timestamp_row = standing_group.loc[standing_group['timestamp'].idxmin()]
        start_timestamp = start_timestamp_row['timestamp']
        dwell_time = (standing_group['timestamp'].max() - start_timestamp).total_seconds()
        start_lat = start_timestamp_row['lat']
        start_lon = start_timestamp_row['lon']

    else:
        start_timestamp_row = group.loc[group['timestamp'].idxmin()]
        start_timestamp = start_timestamp_row['timestamp']
        dwell_time = 0 # If standing is never True, sets dwell_time as 0
        start_lat = start_timestamp_row['lat']
        start_lon = start_timestamp_row['lon']

    return pd.Series([start_timestamp, dwell_time, start_lat, start_lon], index=['timestamp', 'dwell_time', 'lat', 'lon'])

def create_travel_time_df(group):
    if group['standing'].any():  # bus was standing in this stop
        start_row = group[group['standing'] == True].iloc[-1]
        start_row['type'] = 'travel'
        next_group = df[df['group'] == group.name + 1]
        if not next_group.empty:  # next stop exists
            if next_group['standing'].any():  # bus is standing in the next stop
                next_row = next_group[next_group['standing'] == True].iloc[0]
            else:  # bus is not stopping in the next stop
                next_row = next_group.iloc[0]
            start_row['difference'] = next_row['timestamp'] - start_row['timestamp']
            start_row['travel_time'] = start_row['difference'].total_seconds()
        else:  # no next stop
            start_row['difference'] = pd.NaT
            start_row['travel_time'] = np.NaN
    else:  # bus is not stopping in this stop
        start_row = group.iloc[0]
        start_row['type'] = 'travel'
        next_group = df[df['group'] == group.name + 1]
        if not next_group.empty:  # next stop exists
            if next_group['standing'].any():  # bus is standing in the next stop
                next_row = next_group[next_group['standing'] == True].iloc[0]
            else:  # bus is not stopping in the next stop
                next_row = next_group.iloc[0]
            start_row['difference'] = next_row['timestamp'] - start_row['timestamp']
            start_row['travel_time'] = start_row['difference'].total_seconds()
        else:  # no next stop
            start_row['difference'] = pd.NaT
            start_row['travel_time'] = np.NaN
    return start_row


def calculate_travel_times(df):
    df["timestamp"] = df.apply(lambda row: row["timestamp"].replace(tzinfo=None, microsecond=0), axis=1)
    # create groups of consecutive rows with same stop_id
    df["group"] = (df["stop_id"] != df["stop_id"].shift()).cumsum()

    df_dwell = df.groupby(['stop_id', 'group']).apply(calculate_dwell_start).reset_index()

    travel_time_df = df.groupby(['group']).apply(create_travel_time_df).reset_index(drop=True)

    travel_time_df["prev"] = travel_time_df["stop_id"].shift(-1, fill_value=66)
    # create a segment_id for each row based on in_stop and prev columns
    travel_time_df["segment_id"] = travel_time_df.apply(lambda x: create_segment_ids(x["stop_id"], x["prev"]), axis=1)

    df_dwell.rename(columns={"stop_id": "segment_id"}, inplace=True)
    
    travel_time_df = travel_time_df[["timestamp", "lat", "lon", "travel_time", "segment_id"]]
    df_dwell = df_dwell[["timestamp", "lat", "lon", "dwell_time", "segment_id"]]

    travel_time_df.rename(columns={"timestamp": "date"}, inplace=True)
    travel_time_df.reset_index(drop=True)

    df_dwell.rename(columns={"timestamp": "date"}, inplace=True)
    df_dwell.reset_index(drop=True)
    return travel_time_df, df_dwell


def segment_is_correct(segment, ids):
    if segment in ids:
        return True
    else:
        return False


def check_segments(travel_time_df, df_dwell, constants):
    segment_ids = constants.SEGMENT_IDS_FILTERED
    stop_ids = constants.STOP_IDS_FILTERED
    n_samples_original = len(travel_time_df) + len(df_dwell)
    # check if segment_id is correct
    print(df_dwell["segment_id"][2] in stop_ids)
    print(df_dwell["segment_id"][2])
    travel_time_df["correct_segment_ids"] = travel_time_df.apply(
        lambda row: segment_is_correct(row["segment_id"], segment_ids), axis=1
    )
    df_dwell["correct_stop_ids"] = df_dwell.apply(
        lambda row: segment_is_correct(row["segment_id"], stop_ids), axis=1
    )
    # delete rows with incorrect segment_id
    travel_times = travel_time_df[travel_time_df["correct_segment_ids"] == True]
    dwell_times = df_dwell[df_dwell["correct_stop_ids"] == True]
    # delete unnecessary columns
    travel_times = travel_times.drop(columns=["correct_segment_ids"])
    dwell_times = dwell_times.drop(columns=["correct_stop_ids"])
    travel_times = travel_times.reset_index(drop=True)
    dwell_times = dwell_times.reset_index(drop=True)

    n_samples_later = len(travel_times) + len(dwell_times)
    print("---Deleted {} invalid segments".format(n_samples_original - n_samples_later))

    return travel_times, dwell_times


def segments_info(data):
    # compute mean, min, max, std, q25, q50, q75, q95
    if "travel_time" in data.columns:
        attribute = "travel_time"
    else:
        attribute = "dwell_time"

    cut_off_factor = 1.5
    segments_info = data.groupby("segment_id")[attribute].agg(
        [
            "mean",
            "min",
            "max",
            "std",
            ("q25", lambda x: np.percentile(x, 25)),
            ("q50", lambda x: np.percentile(x, 50)),
            ("q75", lambda x: np.percentile(x, 75)),
            ("q95", lambda x: np.percentile(x, 95)),
        ]
    )
    # compute interquantile ranges
    segments_info["iqr"] = segments_info["q75"] - segments_info["q25"]
    # compute outliers cut offs
    segments_info["lower"] = np.maximum(
        segments_info["q25"] - (cut_off_factor * segments_info["iqr"]),
        segments_info["min"],
    )
    segments_info["upper"] = np.minimum(
        segments_info["q75"] + (cut_off_factor * segments_info["iqr"]),
        segments_info["max"],
    )
    return segments_info


def remove_outliers_tt(data, iqr=True):
    print(f"Initial number of samples: {len(data)}")
    data = data[data["travel_time"] > 0]
    mask = (data["segment_id"] == "4_0") & (data["travel_time"] > 650)
    data = data[~mask]
    print("removed tt < 0 and tt > 650")
    print(f"Number of samples after removing outliers manually: {len(data)}")
    ######## 2) Removing outliers automatically - IQR method #########

    # IMPORTANT! This step must be made after removing manually the outliers since the iqr, lower and upper values change
    # after removing some samples manually -> recompute iqr_stats
    if iqr:
        iqr_stats = segments_info(data)

        # considering outliers the samples with travel_time above upper - the ones under the lower limit are not outliers since they can correspond to real data in which a bus doesnt stops
        data = data.assign(
            outlier_iqr=data.apply(
                lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper,
                axis=1,
            )
        )
        # data["outlier_iqr"] = data.apply(lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper, axis=1)

        print(
            "Removing {} outliers detected by IQR method.".format(
                data[(data["outlier_iqr"] == True)]["travel_time"].count()
            )
        )
        data = data[data["outlier_iqr"] == False]

        data = data.drop(columns=["outlier_iqr"])
        data = data.reset_index(drop=True)

        print("After removing outliers, the dataset set is formed by {} samples.".format(data["travel_time"].count()))
    return data


def remove_outliers_dt(data, iqr=True):
    print(f"Initial number of samples: {len(data)}")
    data = data[data["dwell_time"] > 0]
    print(f"Number of samples after removing outliers manually: {len(data)}")
    ######## 2) Removing outliers automatically - IQR method #########

    # IMPORTANT! This step must be made after removing manually the outliers since the iqr, lower and upper values change
    # after removing some samples manually -> recompute iqr_stats
    if iqr:
        iqr_stats = segments_info(data)

        # considering outliers the samples with travel_time above upper - the ones under the lower limit are not outliers since they can correspond to real data in which a bus doesnt stops
        data = data.assign(
            outlier_iqr=data.apply(
                lambda row: row["dwell_time"] > iqr_stats.loc[row["segment_id"]].upper,
                axis=1,
            )
        )
        # data["outlier_iqr"] = data.apply(lambda row: row["travel_time"] > iqr_stats.loc[row["segment_id"]].upper, axis=1)

        print(
            "Removing {} outliers detected by IQR method.".format(
                data[(data["outlier_iqr"] == True)]["dwell_time"].count()
            )
        )
        data = data[data["outlier_iqr"] == False]

        data = data.drop(columns=["outlier_iqr"])
        data = data.reset_index(drop=True)

        print("After removing outliers, the dataset set is formed by {} samples.".format(data["dwell_time"].count()))
    return data


def encode_time(time_obj):
    return (time_obj.hour * 4) + (time_obj.minute // 15)


def add_time_encoding(df):
    day = df["date"].apply(lambda x: x.weekday())
    df["date"] = df.apply(lambda row: row["date"].replace(tzinfo=None, microsecond=0), axis=1)
    df["tod"] = (
        (df["date"] - pd.TimedeltaIndex(df["date"].dt.minute % 15, "m")) - pd.TimedeltaIndex(df["date"].dt.second, "s")
    ).dt.time
    max_dow = 6  # it must be the maximum possible value, not the maximum registered

    df["dow_sin"] = np.sin(2 * np.pi * day / max_dow)
    df["dow_cos"] = np.cos(2 * np.pi * day / max_dow)

    max_tod = 95  # it must be the maximum possible value (23:45:00, not the maximum registered value)
    df["tod_encoded"] = df.apply(lambda row: encode_time(row["tod"]), axis=1)

    df["tod_sin"] = np.round(np.sin(2 * np.pi * df["tod_encoded"] / max_tod), decimals=6)
    df["tod_cos"] = np.round(np.cos(2 * np.pi * df["tod_encoded"] / max_tod), decimals=6)
    df.drop(columns=["tod_encoded"], inplace=True)
    return df


def add_weather(data):
    data["date_1h"] = data.apply(
        lambda row: row["date"].replace(minute=0, second=0, microsecond=0), axis=1
    )  # identifying 1 hour intervals in the data
    start = data.date.min() - timedelta(days=1)
    end = data.date.max() + timedelta(days=1)
    weather_data = (
        Hourly("11331", start, end).fetch().reset_index()
    )  # gets a dataset with weather info (1 hour intervals) at station number 02763 - Tampere
    weather_data = weather_data[["time", "temp", "prcp", "snow", "wspd"]]
    weather_data = weather_data.fillna(0)

    data_with_weather = pd.merge(
        data, weather_data, how="left", left_on="date_1h", right_on="time"
    )  # left join adds weather to dataset. Join on 'date_1h' and 'time'
    data_with_weather = data_with_weather.drop(columns=["date_1h", "time"])
    return data_with_weather


def get_hist_data(obs, data, constants, TT=True, horizon=4):  # data already sorted by time
    date = obs["date"]
    data_filtered = data[data["date"] < date]
    data_filtered = data_filtered.groupby("segment_id")
    data_filtered = data_filtered.tail(horizon)
    data_filtered["delta"] = data_filtered["date"].apply(lambda row: (date - row).total_seconds())
    data_filtered["delta"] = data_filtered["date"].apply(lambda row: (date - row).total_seconds())
    if TT:
        data_filtered = data_filtered[["segment_id", "travel_time", "delta"]]
        l = [data_filtered[data_filtered["segment_id"] == s].to_numpy() for s in constants.SEGMENT_IDS]
    else:
        data_filtered = data_filtered[["segment_id", "dwell_time", "delta"]]
        l = [data_filtered[data_filtered["segment_id"] == s].to_numpy() for s in constants.STOP_IDS_FILTERED]
    for i in range(len(l)):  # zero pad
        if l[i].shape != (4, 3):
            l[i] = np.vstack([l[i], np.zeros([4 - l[i].shape[0], 3])])
    return np.stack(l)


if __name__ == "__main__":
    #add parameter via argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--vehicle_id", type=str, default="2")
    args = parser.parse_args()
    vehicle_id = args.vehicle_id

    print("loading data...")
    df = pd.read_csv("/mnt/raid/csasc_storage/raw/Carinthia/states_pdc-por-02_2022-01-01_to_2022-12-20.csv")
    df2 = pd.read_csv("/mnt/raid/csasc_storage/raw/Carinthia/states_pdc-por-03_2022-01-01_to_2022-12-20.csv")
    df3 = pd.read_csv("/mnt/raid/csasc_storage/raw/Carinthia/states_pdc-por-04_2022-01-01_to_2022-12-20_part1.csv")
    df4 = pd.read_csv("/mnt/raid/csasc_storage/raw/Carinthia/states_pdc-por-04_2022-01-01_to_2022-12-20_part2.csv")
    df = pd.concat([df, df2, df3, df4])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
    #reset index
    df = df.sort_values('timestamp')
    df.reset_index(drop=True, inplace=True)
    #df = df[3600:4000]
    #sort by timestamp
    
    df.rename(columns={'GEO_POSITION_latitude': 'lat', 'GEO_POSITION_longitude': 'lon'}, inplace=True)
    df.rename(columns={'SPEED':'speed'}, inplace=True)

    df["timestamp"] = df.apply(lambda row: row["timestamp"].replace(tzinfo=None, microsecond=0), axis=1)

    #df = df.drop_duplicates(subset='timestamp', keep='first')
    
    print(df.columns)
    print(df.head())
    print(len(df))
    constants = OmegaConf.load("/home/csasc/SHOW_ML_Service/data/processed/CARINTHIA/constants.yaml")
    # transform data to datetime
    #if type(df["timestamp"][0]) != pd._libs.tslibs.timestamps.Timestamp:
    #    df["timestamp"] = df.apply(lambda row: dateutil.parser.parse(row["timestamp"]), axis=1)
    df = df.sort_values("timestamp")
    print("adding stops info...")
    NEW_STOPS = constants.STOPS
    NEXT_STOPS = constants.NEXT_STOPS
    for i in NEXT_STOPS:
        NEXT_STOPS[i].append(i)

    df = add_stops_info(df, stops=NEW_STOPS, next_stops=NEXT_STOPS) 
    print("calculate travel and dwell times...")
    travel_time_df, df_dwell = calculate_travel_times(df)
    travel_time_df.sort_values("date", inplace=True)
    df_dwell.sort_values("date", inplace=True)
    
    #travel_times, dwell_times = check_segments(travel_time_df, df_dwell, constants)
    travel_times = travel_time_df
    dwell_times = df_dwell
    #travel_times = remove_outliers_tt(travel_times)
    #dwell_times = remove_outliers_dt(dwell_times)
    print("adding time encoding...")
    travel_times = add_time_encoding(travel_times)
    #print(dwell_times)
    dwell_times = add_time_encoding(dwell_times)

    travel_times = add_weather(travel_times)
    dwell_times = add_weather(dwell_times)
    print(travel_times)
    print(dwell_times)


    print(travel_times)
    
    travel_times.to_csv(
        f"/home/csasc/SHOW_ML_Service/data/interim/CARINTHIA/CARINTHIA_travel_times_new.csv",
        index=False,
    )

    dwell_times.to_csv(
        f"/home/csasc/SHOW_ML_Service/data/interim/CARINTHIA/CARINTHIA_dwell_times_new.csv",
        index=False,
    )

